﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Negocio;
using Dados;

namespace Controle
{
    public class CtrlClient
    {
        public void SalvarClientNoArquivo(String _path, Client _c)
        {
            try
            {
                ClientDAO dao = new ClientDAO();

                dao.SalvarClientNoArquivo(_path, _c);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public Dictionary<Guid, Client> ObterClientsDoArquivo(String _path)
        {
            try
            {
                ClientDAO dao = new ClientDAO();

                return dao.ObterClientsDoArquivo(_path);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        public Object ExecutarOpBD(char _c, Object _o)
        {
            try
            {
                ClientDAO dao = new ClientDAO();
                switch (_c)
                {
                    case 'i':
                        return dao.Inserir((Client)_o);
                    case 'd':
                        return dao.Deletar(((Client)_o).Id);
                    case 'a':
                        return dao.Atualizar((Client)_o);
                    case 't':
                        return dao.BuscarTodos();
                    case 'o':
                        return dao.BuscarPorID((Guid)_o);
                    default:
                        return null;
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
    }
}
