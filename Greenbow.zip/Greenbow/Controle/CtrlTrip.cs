﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Negocio;
using Dados;

namespace Controle
{
    public class CtrlTrip
    {
        public void SalvarTripNoArquivo(String _path, Trip _t)
        {
            try
            {
                TripDAO dao = new TripDAO();

                dao.SalvarTripNoArquivo(_path, _t);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public Dictionary<Guid, Trip> ObterTripsDoArquivo(String _path)
        {
            try
            {
                TripDAO dao = new TripDAO();

                return dao.ObterTripsDoArquivo(_path);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
    }
}
