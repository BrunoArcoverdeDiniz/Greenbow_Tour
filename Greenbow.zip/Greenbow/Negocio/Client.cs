﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Negocio
{
    public class Client
    {
        //private int id;
        public Guid Id { get; set; }
        public String First { get; set; }
        public String Last { get; set; }
        public String Company { get; set; }
        public String Email { get; set; }
        public String Address { get; set; }
        public String Tel1 { get; set; }
        public String Tel2 { get; set; }
        public String Tel3 { get; set; }
        public Int32 City { get; set; }
        public Int32 State { get; set; }
        public Int32 Country { get; set; }
        public String Zip { get; set; }



    }
}
