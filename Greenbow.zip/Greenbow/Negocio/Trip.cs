﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Negocio
{
    public class Trip
    {
        //private int id;
        public Guid Id { get; set; }
        public String From { get; set; }
        public String To { get; set; }
        public String Driver { get; set; }
        public String Fare { get; set; }
        public String Calendar { get; set; }
        public String Clr { get; set; }
        public int Adults { get; set; }
        public int Children { get; set; }
        public String Via { get; set; }
        public String OWTime { get; set; }
        public String RTTime { get; set; }
        public String FirstName { get; set; }
        public String LastName { get; set; }
        public String Tel { get; set; }
        public String Hotel { get; set; }
        public String Room { get; set; }

    }
}
