﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Negocio;
using System.IO;
using System.Data.SqlServerCe;

namespace Dados
{
    public class ClientDAO
    {
        public void SalvarClientNoArquivo(String _path, Client _c)
        {
            try
            {
                StreamWriter escritor = new StreamWriter(_path, true);

                escritor.Write(_c.Id + ";");
                escritor.Write(_c.First + ";");
                escritor.Write(_c.Last + ";");
                escritor.Write(_c.Company + ";");
                escritor.Write(_c.Email + ";");
                escritor.Write(_c.Address + ";");
                escritor.Write(_c.Tel1 + ";");
                escritor.Write(_c.Tel2 + ";");
                escritor.Write(_c.Tel3 + ";");
                escritor.Write(_c.City + ";");
                escritor.Write(_c.State + ";");
                escritor.Write(_c.Country + ";");
                escritor.Write(_c.Zip + ";");

                escritor.WriteLine();

                escritor.Close();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public Dictionary<Guid, Client> ObterClientsDoArquivo(String _path)
        {
            StreamReader leitor = new StreamReader(_path);
            try
            {
                Dictionary<Guid, Client> listaClients = new Dictionary<Guid, Client>();

                char[] separadorLinhas = { '\n' };
                char[] separadorColunas = { ';' };

                String arquivo = leitor.ReadToEnd();

                String[] linhas = arquivo.Split(separadorLinhas);

                for (int i = 0; i < linhas.Length - 1; i++)
                {
                    String[] colunas = linhas[i].Split(separadorColunas);

                    Client c = new Client();

                    c.Id = new Guid(colunas[0]);
                    c.First = colunas[1];
                    c.Last = colunas[2];
                    c.Company = colunas[3];
                    c.Email = colunas[4];
                    c.Address = colunas[5];
                    c.Tel1 = colunas[6];
                    c.Tel2 = colunas[7];
                    c.Tel3 = colunas[8];
                    c.City = Int32.Parse(colunas[9]);
                    c.State = Int32.Parse(colunas[10]);
                    c.Country = Int32.Parse(colunas[11]);
                    c.Zip = colunas[12];

                    listaClients.Add(c.Id, c);
                }

                return listaClients;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        public int Inserir(Client _o)
        {
            try
            {
                string SQL = String.Format("INSERT INTO client "
                + "(id, first, last, company, email, address, tel1, tel2, tel3, city, state, country, zip)"
                + "VALUES ('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}','{8}',{9},{10},{11},'{12}')",
                _o.Id,
                _o.First,
                _o.Last,
                _o.Company,
                _o.Email,
                _o.Address,
                _o.Tel1,
                _o.Tel2,
                _o.Tel3,
                _o.City,
                _o.State,
                _o.Country,
                _o.Zip
                );

                return BD.ExecutarIDU(SQL);
            }
            catch (Exception ex)
            {
                BD.FecharConexao();
                throw new Exception(ex.Message);
            }
        }

        public int Deletar(Guid _id)
        {
            try
            {
                string SQL = String.Format("DELETE FROM cliente WHERE id = {0}", _id);

                return BD.ExecutarIDU(SQL);
            }
            catch (Exception ex)
            {
                BD.FecharConexao();
                throw new Exception(ex.Message);
            }
        }

        public int Atualizar(Client _o)
        {
            try
            {
                string SQL = String.Format("UPDATE client SET "
                    + "first = '{0}',"
                    + "last = '{1}',"
                    + "company = {2},"
                    + "email = '{3}',"
                    + "address = {4},"
                    + "tel1 = {5},"
                    + "tel2 = '{6}',"
                    + "tel3 = '{7}',"
                    + "city = '{8}',"
                    + "state = '{9}'"
                    + "country = '{10}'"
                    + "zip = '{11}'"
                    + " WHERE id = {12}",
                    _o.First,
                    _o.Last,
                    _o.Company,
                    _o.Email,
                    _o.Address,
                    _o.Tel1,
                    _o.Tel2,
                    _o.Tel3,
                    _o.City,
                    _o.State,
                    _o.Country,
                    _o.Zip,
                    _o.Id
                    );

                return BD.ExecutarIDU(SQL);
            }
            catch (Exception ex)
            {
                BD.FecharConexao();
                throw new Exception(ex.Message);
            }
        }

        public List<Client> BuscarTodos()
        {
            try
            {
                List<Client> listClients = new List<Client>();

                string SQL = "SELECT * FROM client";

                SqlCeDataReader data = BD.ExecutarSelect(SQL);

                while (data.Read())
                {
                    Client c = new Client();

                    c.Id = data.GetGuid(0);
                    c.First = data.GetString(1);
                    c.Last = data.GetString(2);
                    c.Company = data.GetString(3);
                    c.Email = data.GetString(4);
                    c.Address = data.GetString(5);
                    c.Tel1 = data.GetString(6);
                    c.Tel2 = data.GetString(7);
                    c.Tel3 = data.GetString(8);
                    c.City = data.GetInt32(9);
                    c.State = data.GetInt32(10);
                    c.Country = data.GetInt32(11);
                    c.Zip = data.GetString(12);
   

                    listClients.Add(c);
                }

                data.Close();
                BD.FecharConexao();

                return listClients;
            }
            catch (Exception ex)
            {
                BD.FecharConexao();
                throw new Exception(ex.Message);
            }
        }

        public Client BuscarPorID(Guid _id)
        {
            try
            {
                string SQL = String.Format("SELECT * FROM client WHERE id = {0}", _id);

                SqlCeDataReader data = BD.ExecutarSelect(SQL);

                Client c = null;

                if (data.Read())
                {
                    c = new Client();

                    c.Id = data.GetGuid(0);
                    c.First = data.GetString(1);
                    c.Last = data.GetString(2);
                    c.Company = data.GetString(3);
                    c.Email = data.GetString(4);
                    c.Address = data.GetString(5);
                    c.Tel1 = data.GetString(6);
                    c.Tel2 = data.GetString(7);
                    c.Tel3 = data.GetString(8);
                    c.City = data.GetInt32(9);
                    c.State = data.GetInt32(10);
                    c.Country = data.GetInt32(11);
                    c.Zip = data.GetString(12);
                }

                data.Close();
                BD.FecharConexao();

                return c;
            }
            catch (Exception ex)
            {
                BD.FecharConexao();
                throw new Exception(ex.Message);
            }
        }
    }
}
