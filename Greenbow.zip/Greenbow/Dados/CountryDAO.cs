﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Negocio;
using System.Data.SqlServerCe;

namespace Dados
{
    public class CountryDAO
    {
        public int Inserir(State _o)
        {
            try
            {
                string SQL = String.Format("INSERT INTO country "
                + "(descricao)"
                + " VALUES ('{0}')",
                _o.Descricao
                );

                return BD.ExecutarIDU(SQL);
            }
            catch (Exception ex)
            {
                BD.FecharConexao();
                throw new Exception(ex.Message);
            }
        }

        public int Deletar(Int32 _id)
        {
            try
            {
                string SQL = String.Format("DELETE FROM country WHERE id = {0}", _id);

                return BD.ExecutarIDU(SQL);
            }
            catch (Exception ex)
            {
                BD.FecharConexao();
                throw new Exception(ex.Message);
            }
        }

        public int Atualizar(State _o)
        {
            try
            {
                string SQL = String.Format("UPDATE country SET"
                    + "descricao = '{0}'"
                    + " WHERE id = {1}",
                    _o.Descricao,
                    _o.Id
                    );

                return BD.ExecutarIDU(SQL);
            }
            catch (Exception ex)
            {
                BD.FecharConexao();
                throw new Exception(ex.Message);
            }
        }

        public List<State> BuscarTodos()
        {
            try
            {
                List<State> listCountries = new List<State>();

                string SQL = "SELECT * FROM country";

                SqlCeDataReader data = BD.ExecutarSelect(SQL);

                while (data.Read())
                {
                    State o = new State();

                    o.Id = data.GetInt32(0);
                    o.Descricao = data.GetString(1);

                    listCountries.Add(o);
                }

                data.Close();
                BD.FecharConexao();

                return listCountries;
            }
            catch (Exception ex)
            {
                BD.FecharConexao();
                throw new Exception(ex.Message);
            }
        }

        public State BuscarPorID(Int32 _id)
        {
            try
            {
                string SQL = String.Format("SELECT * FROM country WHERE id = {0}", _id);

                SqlCeDataReader data = BD.ExecutarSelect(SQL);

                State o = null;

                if (data.Read())
                {
                    o = new State();

                    o.Id = data.GetInt32(0);
                    o.Descricao = data.GetString(1);
                }

                data.Close();
                BD.FecharConexao();

                return o;
            }
            catch (Exception ex)
            {
                BD.FecharConexao();
                throw new Exception(ex.Message);
            }
        }
    }
}
