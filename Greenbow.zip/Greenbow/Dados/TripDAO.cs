﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Negocio;
using System.IO;

namespace Dados
{
    public class TripDAO
    {
        public void SalvarTripNoArquivo(String _path, Trip _t)
        {
            try
            {
                StreamWriter escritor = new StreamWriter(_path, true);

                escritor.Write(_t.Id + ";");
                escritor.Write(_t.From + ";");
                escritor.Write(_t.To + ";");
                escritor.Write(_t.Driver + ";");
                escritor.Write(_t.Fare + ";");
                escritor.Write(_t.Calendar + ";");
                escritor.Write(_t.Clr + ";");
                escritor.Write(_t.FirstName + ";");
                escritor.Write(_t.LastName + ";");
                escritor.Write(_t.Tel + ";");
                escritor.Write(_t.Adults + ";");
                escritor.Write(_t.Children + ";");
                escritor.Write(_t.Hotel + ";");
                escritor.Write(_t.Room + ";");
                escritor.Write(_t.Via + ";");


                escritor.WriteLine();

                escritor.Close();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public Dictionary<Guid, Trip> ObterTripsDoArquivo(String _path)
        {
            StreamReader leitor = new StreamReader(_path);
            try
            {
                Dictionary<Guid, Trip> listaTrips = new Dictionary<Guid, Trip>();

                char[] separadorLinhas = { '\n' };
                char[] separadorColunas = { ';' };

                String arquivo = leitor.ReadToEnd();

                String[] linhas = arquivo.Split(separadorLinhas);

                for (int i = 0; i < linhas.Length - 1; i++)
                {
                    String[] colunas = linhas[i].Split(separadorColunas);

                    Trip t = new Trip();

                    t.Id = new Guid(colunas[0]);
                    t.From = colunas[1];
                    t.To = colunas[2];
                    t.Driver = colunas[3];
                    t.Fare = colunas[4];
                    t.Calendar = colunas[5];
                    t.Clr = colunas[6];
                    t.FirstName = colunas[7];
                    t.LastName = colunas[8];
                    t.Tel = colunas[9];
                    t.Adults = Int32.Parse(colunas[10]);
                    t.Children = Int32.Parse(colunas[11]);
                    t.Hotel = colunas[12];
                    t.Room = colunas[13];
                    t.Via = colunas[14];


                    listaTrips.Add(t.Id, t);
                }

                return listaTrips;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
    }
}
