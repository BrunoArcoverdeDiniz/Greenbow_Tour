﻿namespace Visao
{
    partial class ListTrips
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.dgvDados = new Bunifu.Framework.UI.BunifuCustomDataGrid();
            this.Date = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.From = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.To = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Driver = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Fare = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Last = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.First = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Clr = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Tel1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Tel2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Tel3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Hotel = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Room = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnImprimirTrip = new Bunifu.Framework.UI.BunifuFlatButton();
            this.txbBusca = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.janelaImpressao = new System.Windows.Forms.PrintDialog();
            this.documento = new System.Windows.Forms.PrintDialog();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDados)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvDados
            // 
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.dgvDados.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvDados.BackgroundColor = System.Drawing.Color.Gainsboro;
            this.dgvDados.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvDados.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.SeaGreen;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvDados.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dgvDados.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDados.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Date,
            this.From,
            this.To,
            this.Driver,
            this.Fare,
            this.Last,
            this.First,
            this.Clr,
            this.Tel1,
            this.Tel2,
            this.Tel3,
            this.Hotel,
            this.Room});
            this.dgvDados.DoubleBuffered = true;
            this.dgvDados.EnableHeadersVisualStyles = false;
            this.dgvDados.HeaderBgColor = System.Drawing.Color.SeaGreen;
            this.dgvDados.HeaderForeColor = System.Drawing.Color.White;
            this.dgvDados.Location = new System.Drawing.Point(37, 76);
            this.dgvDados.Name = "dgvDados";
            this.dgvDados.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.dgvDados.RowTemplate.Height = 28;
            this.dgvDados.Size = new System.Drawing.Size(854, 484);
            this.dgvDados.TabIndex = 69;
            // 
            // Date
            // 
            this.Date.HeaderText = "Date";
            this.Date.Name = "Date";
            // 
            // From
            // 
            this.From.HeaderText = "From";
            this.From.Name = "From";
            // 
            // To
            // 
            this.To.HeaderText = "To";
            this.To.Name = "To";
            // 
            // Driver
            // 
            this.Driver.HeaderText = "Driver";
            this.Driver.Name = "Driver";
            // 
            // Fare
            // 
            this.Fare.HeaderText = "Fare";
            this.Fare.Name = "Fare";
            // 
            // Last
            // 
            this.Last.HeaderText = "Last";
            this.Last.Name = "Last";
            // 
            // First
            // 
            this.First.HeaderText = "First";
            this.First.Name = "First";
            // 
            // Clr
            // 
            this.Clr.HeaderText = "Clr";
            this.Clr.Name = "Clr";
            // 
            // Tel1
            // 
            this.Tel1.HeaderText = "Tel1";
            this.Tel1.Name = "Tel1";
            // 
            // Tel2
            // 
            this.Tel2.HeaderText = "Tel2";
            this.Tel2.Name = "Tel2";
            // 
            // Tel3
            // 
            this.Tel3.HeaderText = "Tel3";
            this.Tel3.Name = "Tel3";
            // 
            // Hotel
            // 
            this.Hotel.HeaderText = "Hotel";
            this.Hotel.Name = "Hotel";
            // 
            // Room
            // 
            this.Room.HeaderText = "Room";
            this.Room.Name = "Room";
            // 
            // btnImprimirTrip
            // 
            this.btnImprimirTrip.Activecolor = System.Drawing.Color.DarkGray;
            this.btnImprimirTrip.BackColor = System.Drawing.Color.Gainsboro;
            this.btnImprimirTrip.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnImprimirTrip.BorderRadius = 0;
            this.btnImprimirTrip.ButtonText = "Print";
            this.btnImprimirTrip.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnImprimirTrip.DisabledColor = System.Drawing.Color.Gainsboro;
            this.btnImprimirTrip.Iconcolor = System.Drawing.Color.Transparent;
            this.btnImprimirTrip.Iconimage = null;
            this.btnImprimirTrip.Iconimage_right = null;
            this.btnImprimirTrip.Iconimage_right_Selected = null;
            this.btnImprimirTrip.Iconimage_Selected = null;
            this.btnImprimirTrip.IconMarginLeft = 0;
            this.btnImprimirTrip.IconMarginRight = 0;
            this.btnImprimirTrip.IconRightVisible = true;
            this.btnImprimirTrip.IconRightZoom = 0D;
            this.btnImprimirTrip.IconVisible = true;
            this.btnImprimirTrip.IconZoom = 35D;
            this.btnImprimirTrip.IsTab = true;
            this.btnImprimirTrip.Location = new System.Drawing.Point(776, 590);
            this.btnImprimirTrip.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnImprimirTrip.Name = "btnImprimirTrip";
            this.btnImprimirTrip.Normalcolor = System.Drawing.Color.Gainsboro;
            this.btnImprimirTrip.OnHovercolor = System.Drawing.Color.SeaGreen;
            this.btnImprimirTrip.OnHoverTextColor = System.Drawing.Color.White;
            this.btnImprimirTrip.selected = false;
            this.btnImprimirTrip.Size = new System.Drawing.Size(115, 38);
            this.btnImprimirTrip.TabIndex = 68;
            this.btnImprimirTrip.Text = "Print";
            this.btnImprimirTrip.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnImprimirTrip.Textcolor = System.Drawing.Color.SeaGreen;
            this.btnImprimirTrip.TextFont = new System.Drawing.Font("Century Gothic", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnImprimirTrip.Click += new System.EventHandler(this.btnImprimirTrip_Click);
            // 
            // txbBusca
            // 
            this.txbBusca.BackColor = System.Drawing.Color.Gainsboro;
            this.txbBusca.Location = new System.Drawing.Point(446, 24);
            this.txbBusca.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txbBusca.Name = "txbBusca";
            this.txbBusca.Size = new System.Drawing.Size(445, 26);
            this.txbBusca.TabIndex = 67;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 11F);
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(356, 22);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(82, 25);
            this.label1.TabIndex = 66;
            this.label1.Text = "Busca:";
            // 
            // janelaImpressao
            // 
            this.janelaImpressao.UseEXDialog = true;
            // 
            // documento
            // 
            this.documento.UseEXDialog = true;
            // 
            // ListTrips
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(49)))), ((int)(((byte)(60)))));
            this.Controls.Add(this.dgvDados);
            this.Controls.Add(this.btnImprimirTrip);
            this.Controls.Add(this.txbBusca);
            this.Controls.Add(this.label1);
            this.Name = "ListTrips";
            this.Size = new System.Drawing.Size(928, 650);
            ((System.ComponentModel.ISupportInitialize)(this.dgvDados)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Bunifu.Framework.UI.BunifuCustomDataGrid dgvDados;
        private System.Windows.Forms.DataGridViewTextBoxColumn Date;
        private System.Windows.Forms.DataGridViewTextBoxColumn From;
        private System.Windows.Forms.DataGridViewTextBoxColumn To;
        private System.Windows.Forms.DataGridViewTextBoxColumn Driver;
        private System.Windows.Forms.DataGridViewTextBoxColumn Fare;
        private System.Windows.Forms.DataGridViewTextBoxColumn Last;
        private System.Windows.Forms.DataGridViewTextBoxColumn First;
        private System.Windows.Forms.DataGridViewTextBoxColumn Clr;
        private System.Windows.Forms.DataGridViewTextBoxColumn Tel1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Tel2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Tel3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Hotel;
        private System.Windows.Forms.DataGridViewTextBoxColumn Room;
        private Bunifu.Framework.UI.BunifuFlatButton btnImprimirTrip;
        private System.Windows.Forms.TextBox txbBusca;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PrintDialog janelaImpressao;
        private System.Windows.Forms.PrintDialog documento;
    }
}
