﻿
using Negocio;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Visao
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }


        private void bunifuFlatButton1_Click(object sender, EventArgs e)
        {
            

        }

        private void bunifuFlatButton2_Click(object sender, EventArgs e)
        {
           
        }

        private void bunifuFlatButton3_Click(object sender, System.EventArgs e)
        {
           

        }


        private void btnMenu_Click(object sender, EventArgs e)
        {
            if (slidemenu.Width == 50)
            {
                //expand
                //1) expand panel .. width = 260
                //2) show logo
            }
            else
            {
                //Minimize
                //using animator
                //1) hide logo
                //2) slide panel width = 50
            }
        }

        private void bunifuFlatButton4_Click(object sender, EventArgs e)
        {
            
        }

        private void panelMain_Paint(object sender, PaintEventArgs e)
        {

        }

        private void bunifuImageButton2_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }

        private void addTripButton_Click(object sender, EventArgs e)
        {
            panel1.Controls.Clear();
            AddTripControl novoTrip = new AddTripControl();
            panel1.Controls.Add(novoTrip);
            novoTrip.Show();
        }

        private void bunifuFlatButton3_Click_1(object sender, EventArgs e)
        {
            panel1.Controls.Clear();
            ListTrips novoTripSearch = new ListTrips();
            panel1.Controls.Add(novoTripSearch);
            novoTripSearch.Show();
            //if (janelaAbrir.ShowDialog() == DialogResult.OK)
            //{
            //    String path = janelaAbrir.FileName;

            //    frmListagem formulario = new frmListagem();

            //    formulario.Tag = path;

            //    formulario.ShowDialog();
            //}
        }

        private void addClientButton_Click(object sender, EventArgs e)
        {
            panel1.Controls.Clear();
            AddClientControl novoClient = new AddClientControl();
            panel1.Controls.Add(novoClient);
            novoClient.Show();
        }

        private void bunifuFlatButton4_Click_1(object sender, EventArgs e)
        {
            panel1.Controls.Clear();
            ListClients novoClientSearch = new ListClients();
            novoClientSearch.TopLevel = false;
            panel1.Controls.Add(novoClientSearch);
            novoClientSearch.Show();
           
        }

        private void btnMenu_Click_1(object sender, EventArgs e)
        {
            
        }
    }
}
