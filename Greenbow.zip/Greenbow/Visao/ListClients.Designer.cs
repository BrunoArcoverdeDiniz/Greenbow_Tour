﻿namespace Visao
{
    partial class ListClients
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.dgvDadosClient = new Bunifu.Framework.UI.BunifuCustomDataGrid();
            this.Date = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.FirstName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.LastName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Company = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Email = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Address = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Tel1Cliente = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Tel2Cliente = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Tel3Cliente = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.City = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.State = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Country = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Zip = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnImprimirClient = new Bunifu.Framework.UI.BunifuFlatButton();
            this.txbBuscaCLient = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.janelaImpressaoClient = new System.Windows.Forms.PrintDialog();
            this.documentClient = new System.Drawing.Printing.PrintDocument();
            this.bunifuElipse1 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.janelaAbrir = new System.Windows.Forms.OpenFileDialog();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDadosClient)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvDadosClient
            // 
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.dgvDadosClient.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvDadosClient.BackgroundColor = System.Drawing.Color.Gainsboro;
            this.dgvDadosClient.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvDadosClient.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.SeaGreen;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvDadosClient.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dgvDadosClient.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDadosClient.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Date,
            this.FirstName,
            this.LastName,
            this.Company,
            this.Email,
            this.Address,
            this.Tel1Cliente,
            this.Tel2Cliente,
            this.Tel3Cliente,
            this.City,
            this.State,
            this.Country,
            this.Zip});
            this.dgvDadosClient.DoubleBuffered = true;
            this.dgvDadosClient.EnableHeadersVisualStyles = false;
            this.dgvDadosClient.HeaderBgColor = System.Drawing.Color.SeaGreen;
            this.dgvDadosClient.HeaderForeColor = System.Drawing.Color.White;
            this.dgvDadosClient.Location = new System.Drawing.Point(37, 76);
            this.dgvDadosClient.Name = "dgvDadosClient";
            this.dgvDadosClient.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.dgvDadosClient.RowTemplate.Height = 28;
            this.dgvDadosClient.Size = new System.Drawing.Size(854, 484);
            this.dgvDadosClient.TabIndex = 70;
            this.dgvDadosClient.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvDadosClient_CellContentClick);
            // 
            // Date
            // 
            this.Date.HeaderText = "Date";
            this.Date.Name = "Date";
            // 
            // FirstName
            // 
            this.FirstName.HeaderText = "First";
            this.FirstName.Name = "FirstName";
            // 
            // LastName
            // 
            this.LastName.HeaderText = "Last";
            this.LastName.Name = "LastName";
            // 
            // Company
            // 
            this.Company.HeaderText = "Company";
            this.Company.Name = "Company";
            // 
            // Email
            // 
            this.Email.HeaderText = "Email";
            this.Email.Name = "Email";
            // 
            // Address
            // 
            this.Address.HeaderText = "Address";
            this.Address.Name = "Address";
            // 
            // Tel1Cliente
            // 
            this.Tel1Cliente.HeaderText = "Tel1";
            this.Tel1Cliente.Name = "Tel1Cliente";
            // 
            // Tel2Cliente
            // 
            this.Tel2Cliente.HeaderText = "Tel2";
            this.Tel2Cliente.Name = "Tel2Cliente";
            // 
            // Tel3Cliente
            // 
            this.Tel3Cliente.HeaderText = "Tel3";
            this.Tel3Cliente.Name = "Tel3Cliente";
            // 
            // City
            // 
            this.City.HeaderText = "City";
            this.City.Name = "City";
            // 
            // State
            // 
            this.State.HeaderText = "State";
            this.State.Name = "State";
            // 
            // Country
            // 
            this.Country.HeaderText = "Country";
            this.Country.Name = "Country";
            // 
            // Zip
            // 
            this.Zip.HeaderText = "Zip";
            this.Zip.Name = "Zip";
            // 
            // btnImprimirClient
            // 
            this.btnImprimirClient.Activecolor = System.Drawing.Color.DarkGray;
            this.btnImprimirClient.BackColor = System.Drawing.Color.Gainsboro;
            this.btnImprimirClient.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnImprimirClient.BorderRadius = 0;
            this.btnImprimirClient.ButtonText = "Print";
            this.btnImprimirClient.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnImprimirClient.DisabledColor = System.Drawing.Color.Gainsboro;
            this.btnImprimirClient.Iconcolor = System.Drawing.Color.Transparent;
            this.btnImprimirClient.Iconimage = null;
            this.btnImprimirClient.Iconimage_right = null;
            this.btnImprimirClient.Iconimage_right_Selected = null;
            this.btnImprimirClient.Iconimage_Selected = null;
            this.btnImprimirClient.IconMarginLeft = 0;
            this.btnImprimirClient.IconMarginRight = 0;
            this.btnImprimirClient.IconRightVisible = true;
            this.btnImprimirClient.IconRightZoom = 0D;
            this.btnImprimirClient.IconVisible = true;
            this.btnImprimirClient.IconZoom = 35D;
            this.btnImprimirClient.IsTab = true;
            this.btnImprimirClient.Location = new System.Drawing.Point(776, 590);
            this.btnImprimirClient.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnImprimirClient.Name = "btnImprimirClient";
            this.btnImprimirClient.Normalcolor = System.Drawing.Color.Gainsboro;
            this.btnImprimirClient.OnHovercolor = System.Drawing.Color.SeaGreen;
            this.btnImprimirClient.OnHoverTextColor = System.Drawing.Color.White;
            this.btnImprimirClient.selected = false;
            this.btnImprimirClient.Size = new System.Drawing.Size(115, 38);
            this.btnImprimirClient.TabIndex = 69;
            this.btnImprimirClient.Text = "Print";
            this.btnImprimirClient.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnImprimirClient.Textcolor = System.Drawing.Color.SeaGreen;
            this.btnImprimirClient.TextFont = new System.Drawing.Font("Century Gothic", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnImprimirClient.Click += new System.EventHandler(this.btnImprimirClient_Click);
            // 
            // txbBuscaCLient
            // 
            this.txbBuscaCLient.BackColor = System.Drawing.Color.Gainsboro;
            this.txbBuscaCLient.Location = new System.Drawing.Point(446, 24);
            this.txbBuscaCLient.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txbBuscaCLient.Name = "txbBuscaCLient";
            this.txbBuscaCLient.Size = new System.Drawing.Size(445, 26);
            this.txbBuscaCLient.TabIndex = 68;
            this.txbBuscaCLient.TextChanged += new System.EventHandler(this.txbBuscaCLient_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 11F);
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(356, 22);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(82, 25);
            this.label1.TabIndex = 67;
            this.label1.Text = "Busca:";
            // 
            // janelaImpressaoClient
            // 
            this.janelaImpressaoClient.UseEXDialog = true;
            // 
            // bunifuElipse1
            // 
            this.bunifuElipse1.ElipseRadius = 5;
            this.bunifuElipse1.TargetControl = this;
            // 
            // janelaAbrir
            // 
            this.janelaAbrir.DefaultExt = "txt";
            // 
            // ListClients
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.WhiteSmoke;
            this.ClientSize = new System.Drawing.Size(928, 650);
            this.Controls.Add(this.dgvDadosClient);
            this.Controls.Add(this.btnImprimirClient);
            this.Controls.Add(this.txbBuscaCLient);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "ListClients";
            this.Load += new System.EventHandler(this.ListClients_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvDadosClient)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Bunifu.Framework.UI.BunifuCustomDataGrid dgvDadosClient;
        private System.Windows.Forms.DataGridViewTextBoxColumn Date;
        private System.Windows.Forms.DataGridViewTextBoxColumn FirstName;
        private System.Windows.Forms.DataGridViewTextBoxColumn LastName;
        private System.Windows.Forms.DataGridViewTextBoxColumn Company;
        private System.Windows.Forms.DataGridViewTextBoxColumn Email;
        private System.Windows.Forms.DataGridViewTextBoxColumn Address;
        private System.Windows.Forms.DataGridViewTextBoxColumn Tel1Cliente;
        private System.Windows.Forms.DataGridViewTextBoxColumn Tel2Cliente;
        private System.Windows.Forms.DataGridViewTextBoxColumn Tel3Cliente;
        private System.Windows.Forms.DataGridViewTextBoxColumn City;
        private System.Windows.Forms.DataGridViewTextBoxColumn State;
        private System.Windows.Forms.DataGridViewTextBoxColumn Country;
        private System.Windows.Forms.DataGridViewTextBoxColumn Zip;
        private Bunifu.Framework.UI.BunifuFlatButton btnImprimirClient;
        private System.Windows.Forms.TextBox txbBuscaCLient;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PrintDialog janelaImpressaoClient;
        private System.Drawing.Printing.PrintDocument documentClient;
        private Bunifu.Framework.UI.BunifuElipse bunifuElipse1;
        private System.Windows.Forms.OpenFileDialog janelaAbrir;
    }
}
