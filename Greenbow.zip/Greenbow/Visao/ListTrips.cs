﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Negocio;
using Controle;
using System.IO;

namespace Visao
{
    public partial class ListTrips : UserControl
    {
        Dictionary<Guid, Trip> mapaTrips = new Dictionary<Guid, Trip>();

        public ListTrips()
        {
            InitializeComponent();
        }

        private void CarregarBDarquivo(String _filtro)
        {
            try
            {
                String path = (String)this.Tag;

                CtrlTrip controle = new CtrlTrip();

                mapaTrips = controle.ObterTripsDoArquivo(path);

                dgvDados.Rows.Clear();

                if (_filtro.Equals(""))
                {
                    foreach (Trip t in mapaTrips.Values)
                    {
                        dgvDados.Rows.Add(t.Id, t.FirstName);
                    }
                }
                else
                {
                    foreach (Trip t in mapaTrips.Values)
                    {
                        if (t.Id.ToString().Contains(_filtro) || t.FirstName.Contains(_filtro))
                        {
                            dgvDados.Rows.Add(t.Id, t.FirstName);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("ERRO AO ABRIR ARQUIVO: " + ex.Message);
            }
        }

        private void ListTripControl_Load(object sender, EventArgs e)
        {
            CarregarBDarquivo("");
        }

        private void txbBusca_TextChanged(object sender, EventArgs e)
        {
            CarregarBDarquivo(txbBusca.Text);
        }

        private void btnImprimir_Click(object sender, EventArgs e)
        {
            
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dgvDados_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView1_CellPainting(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnImprimirTrip_Click(object sender, EventArgs e)
        {
            if (janelaImpressao.ShowDialog() == DialogResult.OK)
            {
                //documento.Print;
            }
        }

    }
}
