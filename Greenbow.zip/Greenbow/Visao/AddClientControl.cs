﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Negocio;
using Controle;

namespace Visao
{
    public partial class AddClientControl : UserControl
    {
        public AddClientControl()
        {
            InitializeComponent();
        }
        private Client CarregarClientDoForm()
        {
            try
            {
                Client c = new Client();

                System.Guid guid = System.Guid.NewGuid();
                string id = guid.ToString();

                c.Id = Guid.NewGuid();
                c.First = First.Text;
                c.Last = Last.Text;
                c.Company = Company.Text;
                c.Email = Email.Text;
                c.Address = Address.Text;
                c.Tel1 = Tel1.Text;
                c.Tel2 = Tel2.Text;
                c.Tel3 = Tel3.Text;
                c.City = (Int32)cmbCity.SelectedValue; 
                c.State = (Int32)cmbState.SelectedValue;
                c.Country = (Int32)cmbCountry.SelectedValue;
                c.Zip = Zip.Text;

                return c;
            }
            catch (Exception ex)
            {
                MessageBox.Show("ERROR: " + ex.Message);
                return null;
            }
        }



        private void btnCancel_Click(object sender, EventArgs e)
        {

        }


        private void btnClientSave_Click_1(object sender, EventArgs e)
        {
            Client c = CarregarClientDoForm();

            //String path = @"C:\Users\BrunoArcoverdeDiniz\Desktop\Greenbow_Tour2\Greenbow_Tour\bdClient.txt";
            //CHAMADA PARA ESCRITA DO ARQUIVO NA CAMADA ABAIXO

            CtrlClient controle = new CtrlClient();
            //controle.SalvarClientNoArquivo(path, c);

            int resultado = (int)controle.ExecutarOpBD('i', c);

            if (resultado > 0)
            {
                MessageBox.Show("Cadastro efetuado com sucesso!!!");
            }
        }

        private void AddClientControl_Load(object sender, EventArgs e)
        {
            CarregarStates();

            CarregarCities();

            CarregarCountry();

            if (this.Tag != null)
            {
                CarregarFormDeClient();
            }

        }

        private void CarregarStates()
        {
            try
            {
                CtrlState controle = new CtrlState();

                List<State> listStates = (List<State>)controle.ExecutarOpBD('t', null);

                cmbState.DisplayMember = "descricao";
                cmbState.ValueMember = "id";

                cmbState.DataSource = listStates;
            }
            catch (Exception ex)
            {
                MessageBox.Show("ERRO: " + ex.Message);
            }
        }

        private void CarregarCities()
        {
            try
            {
                CtrlCity controle = new CtrlCity();

                List<City> listCities = (List<City>)controle.ExecutarOpBD('t', null);

                cmbCity.DisplayMember = "descricao";
                cmbCity.ValueMember = "id";

                cmbCity.DataSource = listCities;
            }
            catch (Exception ex)
            {
                MessageBox.Show("ERRO: " + ex.Message);
            }
        }

        private void CarregarCountry()
        {
            try
            {
                CtrlCountry controle = new CtrlCountry();

                List<Country> listCountries = (List<Country>)controle.ExecutarOpBD('t', null);

                cmbCountry.DisplayMember = "descricao";
                cmbCountry.ValueMember = "id";

                cmbCountry.DataSource = listCountries;
            }
            catch (Exception ex)
            {
                MessageBox.Show("ERRO: " + ex.Message);
            }
        }

        private void CarregarFormDeClient()
        {
            try
            {
                if (this.Tag != null)
                {
                    Client c = (Client)this.Tag;

                   

                    //mtbCpf.Text = c.Id.ToString();
                    //Id.Guid.NewGuid() = c.Id.Guid.NewGuid();
                    First.Text = c.First;
                    Last.Text = c.Last;
                    Company.Text = c.Company;
                    Email.Text = c.Email;
                    Tel1.Text = c.Tel1;
                    Tel2.Text = c.Tel2;
                    Tel3.Text = c.Tel3;
                    cmbCity.SelectedValue = c.City;
                    cmbState.SelectedValue = c.State;
                    cmbCountry.SelectedValue = c.Country;
                    Zip.Text = c.Zip;

                }

                btnClientSave.Visible = false;
                btnUpdate.Visible = true;
                //mtbCpf.Enabled = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show("ERRO: " + ex.Message);
            }
        }

        private void btnAtualizar_Click(object sender, EventArgs e)
        {
            Client c = CarregarClientDoForm();

            CtrlClient controle = new CtrlClient();

            int resultado = (int)controle.ExecutarOpBD('a', c);

            if (resultado > 0)
            {
                MessageBox.Show("Atualização efetuado com sucesso!!!");
            }
        }
        
        private void bunifuFlatButton5_Click(object sender, EventArgs e)
        {
            //pnlAddClient.Controls.Clear();
            //visao.form1.panel1.controls.clear();
            //Form1 f = new Form1();
            //this.Hide();
            //f.ShowDialog();
            
            //((AddClientControl)this.TopLevelControl).Close();
        }
    }
}
