﻿namespace Visao
{
    partial class AddClientControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlAddClient = new System.Windows.Forms.Panel();
            this.btnUpdate = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btnClientSave = new Bunifu.Framework.UI.BunifuFlatButton();
            this.bunifuFlatButton5 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.cmbCountry = new System.Windows.Forms.ComboBox();
            this.cmbState = new System.Windows.Forms.ComboBox();
            this.cmbCity = new System.Windows.Forms.ComboBox();
            this.dateTimePicker1 = new Bunifu.Framework.UI.BunifuDatepicker();
            this.Zip = new System.Windows.Forms.TextBox();
            this.bunifuCustomLabel13 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel1 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel7 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.Address = new System.Windows.Forms.TextBox();
            this.bunifuCustomLabel8 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel10 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.Email = new System.Windows.Forms.TextBox();
            this.Company = new System.Windows.Forms.TextBox();
            this.bunifuCustomLabel18 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel19 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.Tel3 = new System.Windows.Forms.MaskedTextBox();
            this.bunifuCustomLabel17 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.Tel2 = new System.Windows.Forms.MaskedTextBox();
            this.bunifuCustomLabel3 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.bunifuCustomLabel12 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.Last = new System.Windows.Forms.TextBox();
            this.Tel1 = new System.Windows.Forms.MaskedTextBox();
            this.First = new System.Windows.Forms.TextBox();
            this.bunifuCustomLabel9 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel6 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel11 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel2 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuDatepicker1 = new Bunifu.Framework.UI.BunifuDatepicker();
            this.pnlAddClient.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlAddClient
            // 
            this.pnlAddClient.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(49)))), ((int)(((byte)(60)))));
            this.pnlAddClient.Controls.Add(this.btnUpdate);
            this.pnlAddClient.Controls.Add(this.btnClientSave);
            this.pnlAddClient.Controls.Add(this.bunifuFlatButton5);
            this.pnlAddClient.Controls.Add(this.groupBox3);
            this.pnlAddClient.Controls.Add(this.bunifuCustomLabel2);
            this.pnlAddClient.Controls.Add(this.bunifuDatepicker1);
            this.pnlAddClient.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlAddClient.Location = new System.Drawing.Point(0, 0);
            this.pnlAddClient.Name = "pnlAddClient";
            this.pnlAddClient.Size = new System.Drawing.Size(928, 650);
            this.pnlAddClient.TabIndex = 6;
            // 
            // btnUpdate
            // 
            this.btnUpdate.Activecolor = System.Drawing.Color.DarkGray;
            this.btnUpdate.BackColor = System.Drawing.Color.Gainsboro;
            this.btnUpdate.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnUpdate.BorderRadius = 0;
            this.btnUpdate.ButtonText = "Update";
            this.btnUpdate.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnUpdate.DisabledColor = System.Drawing.Color.Gainsboro;
            this.btnUpdate.Iconcolor = System.Drawing.Color.Transparent;
            this.btnUpdate.Iconimage = null;
            this.btnUpdate.Iconimage_right = null;
            this.btnUpdate.Iconimage_right_Selected = null;
            this.btnUpdate.Iconimage_Selected = null;
            this.btnUpdate.IconMarginLeft = 0;
            this.btnUpdate.IconMarginRight = 0;
            this.btnUpdate.IconRightVisible = true;
            this.btnUpdate.IconRightZoom = 0D;
            this.btnUpdate.IconVisible = true;
            this.btnUpdate.IconZoom = 35D;
            this.btnUpdate.IsTab = true;
            this.btnUpdate.Location = new System.Drawing.Point(522, 587);
            this.btnUpdate.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Normalcolor = System.Drawing.Color.Gainsboro;
            this.btnUpdate.OnHovercolor = System.Drawing.Color.SeaGreen;
            this.btnUpdate.OnHoverTextColor = System.Drawing.Color.White;
            this.btnUpdate.selected = false;
            this.btnUpdate.Size = new System.Drawing.Size(115, 38);
            this.btnUpdate.TabIndex = 64;
            this.btnUpdate.Text = "Update";
            this.btnUpdate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnUpdate.Textcolor = System.Drawing.Color.SeaGreen;
            this.btnUpdate.TextFont = new System.Drawing.Font("Century Gothic", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // btnClientSave
            // 
            this.btnClientSave.Activecolor = System.Drawing.Color.DarkGray;
            this.btnClientSave.BackColor = System.Drawing.Color.Gainsboro;
            this.btnClientSave.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnClientSave.BorderRadius = 0;
            this.btnClientSave.ButtonText = "Save";
            this.btnClientSave.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnClientSave.DisabledColor = System.Drawing.Color.Gainsboro;
            this.btnClientSave.Iconcolor = System.Drawing.Color.Transparent;
            this.btnClientSave.Iconimage = null;
            this.btnClientSave.Iconimage_right = null;
            this.btnClientSave.Iconimage_right_Selected = null;
            this.btnClientSave.Iconimage_Selected = null;
            this.btnClientSave.IconMarginLeft = 0;
            this.btnClientSave.IconMarginRight = 0;
            this.btnClientSave.IconRightVisible = true;
            this.btnClientSave.IconRightZoom = 0D;
            this.btnClientSave.IconVisible = true;
            this.btnClientSave.IconZoom = 35D;
            this.btnClientSave.IsTab = true;
            this.btnClientSave.Location = new System.Drawing.Point(788, 587);
            this.btnClientSave.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnClientSave.Name = "btnClientSave";
            this.btnClientSave.Normalcolor = System.Drawing.Color.Gainsboro;
            this.btnClientSave.OnHovercolor = System.Drawing.Color.SeaGreen;
            this.btnClientSave.OnHoverTextColor = System.Drawing.Color.White;
            this.btnClientSave.selected = false;
            this.btnClientSave.Size = new System.Drawing.Size(115, 38);
            this.btnClientSave.TabIndex = 63;
            this.btnClientSave.Text = "Save";
            this.btnClientSave.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnClientSave.Textcolor = System.Drawing.Color.SeaGreen;
            this.btnClientSave.TextFont = new System.Drawing.Font("Century Gothic", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClientSave.Click += new System.EventHandler(this.btnClientSave_Click_1);
            // 
            // bunifuFlatButton5
            // 
            this.bunifuFlatButton5.Activecolor = System.Drawing.Color.DarkGray;
            this.bunifuFlatButton5.BackColor = System.Drawing.Color.Gainsboro;
            this.bunifuFlatButton5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton5.BorderRadius = 0;
            this.bunifuFlatButton5.ButtonText = "Cancel";
            this.bunifuFlatButton5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuFlatButton5.DisabledColor = System.Drawing.Color.Gainsboro;
            this.bunifuFlatButton5.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton5.Iconimage = null;
            this.bunifuFlatButton5.Iconimage_right = null;
            this.bunifuFlatButton5.Iconimage_right_Selected = null;
            this.bunifuFlatButton5.Iconimage_Selected = null;
            this.bunifuFlatButton5.IconMarginLeft = 0;
            this.bunifuFlatButton5.IconMarginRight = 0;
            this.bunifuFlatButton5.IconRightVisible = true;
            this.bunifuFlatButton5.IconRightZoom = 0D;
            this.bunifuFlatButton5.IconVisible = true;
            this.bunifuFlatButton5.IconZoom = 35D;
            this.bunifuFlatButton5.IsTab = true;
            this.bunifuFlatButton5.Location = new System.Drawing.Point(655, 587);
            this.bunifuFlatButton5.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.bunifuFlatButton5.Name = "bunifuFlatButton5";
            this.bunifuFlatButton5.Normalcolor = System.Drawing.Color.Gainsboro;
            this.bunifuFlatButton5.OnHovercolor = System.Drawing.Color.SeaGreen;
            this.bunifuFlatButton5.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton5.selected = false;
            this.bunifuFlatButton5.Size = new System.Drawing.Size(115, 38);
            this.bunifuFlatButton5.TabIndex = 62;
            this.bunifuFlatButton5.Text = "Cancel";
            this.bunifuFlatButton5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuFlatButton5.Textcolor = System.Drawing.Color.SeaGreen;
            this.bunifuFlatButton5.TextFont = new System.Drawing.Font("Century Gothic", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuFlatButton5.Click += new System.EventHandler(this.bunifuFlatButton5_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.cmbCountry);
            this.groupBox3.Controls.Add(this.cmbState);
            this.groupBox3.Controls.Add(this.cmbCity);
            this.groupBox3.Controls.Add(this.dateTimePicker1);
            this.groupBox3.Controls.Add(this.Zip);
            this.groupBox3.Controls.Add(this.bunifuCustomLabel13);
            this.groupBox3.Controls.Add(this.bunifuCustomLabel1);
            this.groupBox3.Controls.Add(this.bunifuCustomLabel7);
            this.groupBox3.Controls.Add(this.Address);
            this.groupBox3.Controls.Add(this.bunifuCustomLabel8);
            this.groupBox3.Controls.Add(this.bunifuCustomLabel10);
            this.groupBox3.Controls.Add(this.Email);
            this.groupBox3.Controls.Add(this.Company);
            this.groupBox3.Controls.Add(this.bunifuCustomLabel18);
            this.groupBox3.Controls.Add(this.bunifuCustomLabel19);
            this.groupBox3.Controls.Add(this.Tel3);
            this.groupBox3.Controls.Add(this.bunifuCustomLabel17);
            this.groupBox3.Controls.Add(this.Tel2);
            this.groupBox3.Controls.Add(this.bunifuCustomLabel3);
            this.groupBox3.Controls.Add(this.textBox2);
            this.groupBox3.Controls.Add(this.bunifuCustomLabel12);
            this.groupBox3.Controls.Add(this.Last);
            this.groupBox3.Controls.Add(this.Tel1);
            this.groupBox3.Controls.Add(this.First);
            this.groupBox3.Controls.Add(this.bunifuCustomLabel9);
            this.groupBox3.Controls.Add(this.bunifuCustomLabel6);
            this.groupBox3.Controls.Add(this.bunifuCustomLabel11);
            this.groupBox3.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.ForeColor = System.Drawing.Color.White;
            this.groupBox3.Location = new System.Drawing.Point(22, 63);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox3.Size = new System.Drawing.Size(881, 500);
            this.groupBox3.TabIndex = 51;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Client Details";
            // 
            // cmbCountry
            // 
            this.cmbCountry.BackColor = System.Drawing.Color.Gainsboro;
            this.cmbCountry.Font = new System.Drawing.Font("Century Gothic", 10F);
            this.cmbCountry.FormattingEnabled = true;
            this.cmbCountry.Location = new System.Drawing.Point(721, 367);
            this.cmbCountry.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.cmbCountry.Name = "cmbCountry";
            this.cmbCountry.Size = new System.Drawing.Size(116, 31);
            this.cmbCountry.TabIndex = 93;
            // 
            // cmbState
            // 
            this.cmbState.BackColor = System.Drawing.Color.Gainsboro;
            this.cmbState.Font = new System.Drawing.Font("Century Gothic", 10F);
            this.cmbState.FormattingEnabled = true;
            this.cmbState.Location = new System.Drawing.Point(721, 306);
            this.cmbState.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.cmbState.Name = "cmbState";
            this.cmbState.Size = new System.Drawing.Size(116, 31);
            this.cmbState.TabIndex = 92;
            // 
            // cmbCity
            // 
            this.cmbCity.BackColor = System.Drawing.Color.Gainsboro;
            this.cmbCity.Font = new System.Drawing.Font("Century Gothic", 10F);
            this.cmbCity.FormattingEnabled = true;
            this.cmbCity.Location = new System.Drawing.Point(721, 245);
            this.cmbCity.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.cmbCity.Name = "cmbCity";
            this.cmbCity.Size = new System.Drawing.Size(116, 31);
            this.cmbCity.TabIndex = 91;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.BackColor = System.Drawing.Color.Gainsboro;
            this.dateTimePicker1.BorderRadius = 0;
            this.dateTimePicker1.Font = new System.Drawing.Font("Century Gothic", 6F);
            this.dateTimePicker1.ForeColor = System.Drawing.Color.Black;
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Long;
            this.dateTimePicker1.FormatCustom = null;
            this.dateTimePicker1.Location = new System.Drawing.Point(136, 56);
            this.dateTimePicker1.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(387, 32);
            this.dateTimePicker1.TabIndex = 88;
            this.dateTimePicker1.Value = new System.DateTime(2018, 5, 3, 9, 31, 18, 678);
            // 
            // Zip
            // 
            this.Zip.BackColor = System.Drawing.Color.Gainsboro;
            this.Zip.Font = new System.Drawing.Font("Century Gothic", 10F);
            this.Zip.Location = new System.Drawing.Point(721, 427);
            this.Zip.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Zip.Name = "Zip";
            this.Zip.Size = new System.Drawing.Size(116, 32);
            this.Zip.TabIndex = 87;
            // 
            // bunifuCustomLabel13
            // 
            this.bunifuCustomLabel13.AutoSize = true;
            this.bunifuCustomLabel13.Location = new System.Drawing.Point(606, 427);
            this.bunifuCustomLabel13.Name = "bunifuCustomLabel13";
            this.bunifuCustomLabel13.Size = new System.Drawing.Size(99, 23);
            this.bunifuCustomLabel13.TabIndex = 86;
            this.bunifuCustomLabel13.Text = "Zip Code";
            // 
            // bunifuCustomLabel1
            // 
            this.bunifuCustomLabel1.AutoSize = true;
            this.bunifuCustomLabel1.Location = new System.Drawing.Point(606, 369);
            this.bunifuCustomLabel1.Name = "bunifuCustomLabel1";
            this.bunifuCustomLabel1.Size = new System.Drawing.Size(87, 23);
            this.bunifuCustomLabel1.TabIndex = 84;
            this.bunifuCustomLabel1.Text = "Country";
            // 
            // bunifuCustomLabel7
            // 
            this.bunifuCustomLabel7.AutoSize = true;
            this.bunifuCustomLabel7.Location = new System.Drawing.Point(606, 306);
            this.bunifuCustomLabel7.Name = "bunifuCustomLabel7";
            this.bunifuCustomLabel7.Size = new System.Drawing.Size(61, 23);
            this.bunifuCustomLabel7.TabIndex = 81;
            this.bunifuCustomLabel7.Text = "State";
            // 
            // Address
            // 
            this.Address.BackColor = System.Drawing.Color.Gainsboro;
            this.Address.Font = new System.Drawing.Font("Century Gothic", 10F);
            this.Address.Location = new System.Drawing.Point(136, 366);
            this.Address.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Address.Name = "Address";
            this.Address.Size = new System.Drawing.Size(387, 32);
            this.Address.TabIndex = 78;
            // 
            // bunifuCustomLabel8
            // 
            this.bunifuCustomLabel8.AutoSize = true;
            this.bunifuCustomLabel8.Location = new System.Drawing.Point(612, 245);
            this.bunifuCustomLabel8.Name = "bunifuCustomLabel8";
            this.bunifuCustomLabel8.Size = new System.Drawing.Size(47, 23);
            this.bunifuCustomLabel8.TabIndex = 79;
            this.bunifuCustomLabel8.Text = "City";
            // 
            // bunifuCustomLabel10
            // 
            this.bunifuCustomLabel10.AutoSize = true;
            this.bunifuCustomLabel10.Location = new System.Drawing.Point(14, 369);
            this.bunifuCustomLabel10.Name = "bunifuCustomLabel10";
            this.bunifuCustomLabel10.Size = new System.Drawing.Size(88, 23);
            this.bunifuCustomLabel10.TabIndex = 77;
            this.bunifuCustomLabel10.Text = "Address";
            // 
            // Email
            // 
            this.Email.BackColor = System.Drawing.Color.Gainsboro;
            this.Email.Font = new System.Drawing.Font("Century Gothic", 10F);
            this.Email.Location = new System.Drawing.Point(136, 303);
            this.Email.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Email.Name = "Email";
            this.Email.Size = new System.Drawing.Size(387, 32);
            this.Email.TabIndex = 76;
            // 
            // Company
            // 
            this.Company.BackColor = System.Drawing.Color.Gainsboro;
            this.Company.Font = new System.Drawing.Font("Century Gothic", 10F);
            this.Company.Location = new System.Drawing.Point(136, 242);
            this.Company.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Company.Name = "Company";
            this.Company.Size = new System.Drawing.Size(387, 32);
            this.Company.TabIndex = 74;
            // 
            // bunifuCustomLabel18
            // 
            this.bunifuCustomLabel18.AutoSize = true;
            this.bunifuCustomLabel18.Location = new System.Drawing.Point(14, 303);
            this.bunifuCustomLabel18.Name = "bunifuCustomLabel18";
            this.bunifuCustomLabel18.Size = new System.Drawing.Size(69, 23);
            this.bunifuCustomLabel18.TabIndex = 75;
            this.bunifuCustomLabel18.Text = "E-mail";
            // 
            // bunifuCustomLabel19
            // 
            this.bunifuCustomLabel19.AutoSize = true;
            this.bunifuCustomLabel19.Location = new System.Drawing.Point(14, 245);
            this.bunifuCustomLabel19.Name = "bunifuCustomLabel19";
            this.bunifuCustomLabel19.Size = new System.Drawing.Size(109, 23);
            this.bunifuCustomLabel19.TabIndex = 73;
            this.bunifuCustomLabel19.Text = "Company";
            // 
            // Tel3
            // 
            this.Tel3.BackColor = System.Drawing.Color.Gainsboro;
            this.Tel3.Font = new System.Drawing.Font("Century Gothic", 10F);
            this.Tel3.Location = new System.Drawing.Point(684, 182);
            this.Tel3.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Tel3.Mask = "(99) 90000-0000";
            this.Tel3.Name = "Tel3";
            this.Tel3.Size = new System.Drawing.Size(153, 32);
            this.Tel3.TabIndex = 71;
            // 
            // bunifuCustomLabel17
            // 
            this.bunifuCustomLabel17.AutoSize = true;
            this.bunifuCustomLabel17.Location = new System.Drawing.Point(606, 191);
            this.bunifuCustomLabel17.Name = "bunifuCustomLabel17";
            this.bunifuCustomLabel17.Size = new System.Drawing.Size(53, 23);
            this.bunifuCustomLabel17.TabIndex = 72;
            this.bunifuCustomLabel17.Text = "Tel 3";
            // 
            // Tel2
            // 
            this.Tel2.BackColor = System.Drawing.Color.Gainsboro;
            this.Tel2.Font = new System.Drawing.Font("Century Gothic", 10F);
            this.Tel2.Location = new System.Drawing.Point(684, 120);
            this.Tel2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Tel2.Mask = "(99) 90000-0000";
            this.Tel2.Name = "Tel2";
            this.Tel2.Size = new System.Drawing.Size(153, 32);
            this.Tel2.TabIndex = 69;
            // 
            // bunifuCustomLabel3
            // 
            this.bunifuCustomLabel3.AutoSize = true;
            this.bunifuCustomLabel3.Location = new System.Drawing.Point(606, 129);
            this.bunifuCustomLabel3.Name = "bunifuCustomLabel3";
            this.bunifuCustomLabel3.Size = new System.Drawing.Size(53, 23);
            this.bunifuCustomLabel3.TabIndex = 70;
            this.bunifuCustomLabel3.Text = "Tel 2";
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("Century Gothic", 10F);
            this.textBox2.Location = new System.Drawing.Point(384, 594);
            this.textBox2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(175, 32);
            this.textBox2.TabIndex = 59;
            // 
            // bunifuCustomLabel12
            // 
            this.bunifuCustomLabel12.AutoSize = true;
            this.bunifuCustomLabel12.Location = new System.Drawing.Point(321, 600);
            this.bunifuCustomLabel12.Name = "bunifuCustomLabel12";
            this.bunifuCustomLabel12.Size = new System.Drawing.Size(37, 23);
            this.bunifuCustomLabel12.TabIndex = 58;
            this.bunifuCustomLabel12.Text = "Clr";
            // 
            // Last
            // 
            this.Last.BackColor = System.Drawing.Color.Gainsboro;
            this.Last.Font = new System.Drawing.Font("Century Gothic", 10F);
            this.Last.Location = new System.Drawing.Point(136, 176);
            this.Last.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Last.Name = "Last";
            this.Last.Size = new System.Drawing.Size(387, 32);
            this.Last.TabIndex = 68;
            // 
            // Tel1
            // 
            this.Tel1.BackColor = System.Drawing.Color.Gainsboro;
            this.Tel1.Font = new System.Drawing.Font("Century Gothic", 10F);
            this.Tel1.Location = new System.Drawing.Point(684, 56);
            this.Tel1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Tel1.Mask = "(99) 90000-0000";
            this.Tel1.Name = "Tel1";
            this.Tel1.Size = new System.Drawing.Size(153, 32);
            this.Tel1.TabIndex = 34;
            // 
            // First
            // 
            this.First.BackColor = System.Drawing.Color.Gainsboro;
            this.First.Font = new System.Drawing.Font("Century Gothic", 10F);
            this.First.Location = new System.Drawing.Point(136, 115);
            this.First.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.First.Name = "First";
            this.First.Size = new System.Drawing.Size(387, 32);
            this.First.TabIndex = 66;
            // 
            // bunifuCustomLabel9
            // 
            this.bunifuCustomLabel9.AutoSize = true;
            this.bunifuCustomLabel9.Location = new System.Drawing.Point(14, 176);
            this.bunifuCustomLabel9.Name = "bunifuCustomLabel9";
            this.bunifuCustomLabel9.Size = new System.Drawing.Size(48, 23);
            this.bunifuCustomLabel9.TabIndex = 67;
            this.bunifuCustomLabel9.Text = "Last";
            // 
            // bunifuCustomLabel6
            // 
            this.bunifuCustomLabel6.AutoSize = true;
            this.bunifuCustomLabel6.Location = new System.Drawing.Point(606, 65);
            this.bunifuCustomLabel6.Name = "bunifuCustomLabel6";
            this.bunifuCustomLabel6.Size = new System.Drawing.Size(53, 23);
            this.bunifuCustomLabel6.TabIndex = 35;
            this.bunifuCustomLabel6.Text = "Tel 1";
            // 
            // bunifuCustomLabel11
            // 
            this.bunifuCustomLabel11.AutoSize = true;
            this.bunifuCustomLabel11.Location = new System.Drawing.Point(14, 118);
            this.bunifuCustomLabel11.Name = "bunifuCustomLabel11";
            this.bunifuCustomLabel11.Size = new System.Drawing.Size(44, 23);
            this.bunifuCustomLabel11.TabIndex = 65;
            this.bunifuCustomLabel11.Text = "First";
            // 
            // bunifuCustomLabel2
            // 
            this.bunifuCustomLabel2.AutoSize = true;
            this.bunifuCustomLabel2.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel2.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel2.Location = new System.Drawing.Point(382, 11);
            this.bunifuCustomLabel2.Name = "bunifuCustomLabel2";
            this.bunifuCustomLabel2.Size = new System.Drawing.Size(163, 30);
            this.bunifuCustomLabel2.TabIndex = 27;
            this.bunifuCustomLabel2.Text = "Add a Client";
            // 
            // bunifuDatepicker1
            // 
            this.bunifuDatepicker1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.bunifuDatepicker1.BorderRadius = 5;
            this.bunifuDatepicker1.ForeColor = System.Drawing.Color.Black;
            this.bunifuDatepicker1.Format = System.Windows.Forms.DateTimePickerFormat.Long;
            this.bunifuDatepicker1.FormatCustom = null;
            this.bunifuDatepicker1.Location = new System.Drawing.Point(22, 41);
            this.bunifuDatepicker1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.bunifuDatepicker1.Name = "bunifuDatepicker1";
            this.bunifuDatepicker1.Size = new System.Drawing.Size(0, 0);
            this.bunifuDatepicker1.TabIndex = 24;
            this.bunifuDatepicker1.Value = new System.DateTime(2018, 4, 12, 12, 5, 41, 736);
            // 
            // AddClientControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.pnlAddClient);
            this.Name = "AddClientControl";
            this.Size = new System.Drawing.Size(928, 650);
            this.pnlAddClient.ResumeLayout(false);
            this.pnlAddClient.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Bunifu.Framework.UI.BunifuFlatButton btnClientSave;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton5;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.ComboBox cmbCountry;
        private System.Windows.Forms.ComboBox cmbState;
        private System.Windows.Forms.ComboBox cmbCity;
        private Bunifu.Framework.UI.BunifuDatepicker dateTimePicker1;
        private System.Windows.Forms.TextBox Zip;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel13;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel1;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel7;
        private System.Windows.Forms.TextBox Address;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel8;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel10;
        private System.Windows.Forms.TextBox Email;
        private System.Windows.Forms.TextBox Company;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel18;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel19;
        private System.Windows.Forms.MaskedTextBox Tel3;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel17;
        private System.Windows.Forms.MaskedTextBox Tel2;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel3;
        private System.Windows.Forms.TextBox textBox2;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel12;
        private System.Windows.Forms.TextBox Last;
        private System.Windows.Forms.MaskedTextBox Tel1;
        private System.Windows.Forms.TextBox First;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel9;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel6;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel11;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel2;
        private Bunifu.Framework.UI.BunifuDatepicker bunifuDatepicker1;
        private System.Windows.Forms.Panel pnlAddClient;
        private Bunifu.Framework.UI.BunifuFlatButton btnUpdate;
    }
}
