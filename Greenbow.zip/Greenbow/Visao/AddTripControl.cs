﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Negocio;
using Controle;

namespace Visao
{
    public partial class AddTripControl : UserControl
    {
        public AddTripControl()
        {
            InitializeComponent();
        }
        private Trip CarregarTripDoForm()
        {
            try
            {
                Trip t = new Trip();

                System.Guid guid = System.Guid.NewGuid();
                string id = guid.ToString();

                t.Id = Guid.NewGuid();
                t.From = textBox1.Text;
                t.To = txbTo.Text;
                t.Driver = txbDriver.Text;
                t.Fare = txbFare.Text;
                t.Calendar = calendar.Text;
                t.Clr = txbClr.Text;
                t.FirstName = txbFirstName.Text;
                t.LastName = txbLastName.Text;
                t.Tel = mtbTel.Text;
                t.Adults = cmbAdults.SelectedIndex;
                t.Children = cmbChildren.SelectedIndex;
                t.Hotel = txbHotel.Text;
                t.Room = txbRoom.Text;


                //VERICAÇAO DO One Way OR Round Trip - SELEÇAO
                if (rdbOneWay.Checked)
                {
                    t.Via = "oneWay";
                }
                else
                {
                    if (rdbRoundTrip.Checked)
                    {
                        t.Via = "roundTrip";
                    }
                    else
                    {
                        t.Via = "undefined";
                    }
                }

                return t;
            }
            catch (Exception ex)
            {
                MessageBox.Show("ERROR: " + ex.Message);
                return null;
            }
        }

       

        private void btnCancel_Click(object sender, EventArgs e)
        {

        }

        private void btnSave_Click_1(object sender, EventArgs e)
        {
            Trip t = CarregarTripDoForm();

            String path = @"C:\Users\BrunoArcoverdeDiniz\Desktop\UNILASALLE\TOPICOS 2\Greenbow_Tour\bdTrip.txt";
            //CHAMADA PARA ESCRITA DO ARQUIVO NA CAMADA ABAIXO
            CtrlTrip controle = new CtrlTrip();

            controle.SalvarTripNoArquivo(path, t);
        }
    }
}