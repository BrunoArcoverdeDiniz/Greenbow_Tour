﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Negocio;
using Controle;
using System.IO;

namespace Visao
{
    public partial class ListClients : Form
    {
        Dictionary<Guid, Client> mapaClients = new Dictionary<Guid, Client>();

        public ListClients()
        {
            InitializeComponent();
        }

        private void CarregarBDarquivo(String _filtro)
        {
            try
            {
                String path = (String)this.Tag;

                CtrlClient controle = new CtrlClient();

                mapaClients = controle.ObterClientsDoArquivo(path);

                dgvDadosClient.Rows.Clear();

                if (_filtro.Equals(""))
                {
                    foreach (Client c in mapaClients.Values)
                    {
                        dgvDadosClient.Rows.Add(c.First, c.Last);
                    }
                }
                else
                {
                    foreach (Client c in mapaClients.Values)
                    {
                        if (c.First.ToString().Contains(_filtro) || c.Last.Contains(_filtro))
                        {
                            dgvDadosClient.Rows.Add(c.First, c.Last);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("ERRO AO ABRIR ARQUIVO: " + ex.Message);
            }
        }

        private void CarregarClientsBD()
        {
            try
            {
                dgvDadosClient.Rows.Clear();

                CtrlClient controle = new CtrlClient();

                List<Client> clients = (List<Client>)controle.ExecutarOpBD('t', null);

                foreach (Client item in clients)
                {
                    dgvDadosClient.Rows.Add(item.First, item.Last);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("ERRO: " + ex.Message);
            }
        }

        private void ListClients_Load(object sender, EventArgs e)
        {
            if (janelaAbrir.ShowDialog() == DialogResult.OK)
            {
                String path = janelaAbrir.FileName;

                //ListClients formulario = new ListClients();

                this.Tag = path;
                CarregarBDarquivo("");
                //formulario.ShowDialog();
            }
            
            
        }

        private void txbBuscaCLient_TextChanged(object sender, EventArgs e)
        {
            

            CarregarBDarquivo(txbBuscaCLient.Text);
        }


        private void btnImprimirClient_Click(object sender, EventArgs e)
        {
            if (janelaImpressaoClient.ShowDialog() == DialogResult.OK)
            {
                documentClient.Print();
            }
        }

        private void documentClient_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            StringBuilder data = new StringBuilder();

            StringWriter escritor = new StringWriter(data);

            Guid idClient = Guid.Parse(dgvDadosClient.SelectedRows[0].Cells[0].Value.ToString());

            Client c = mapaClients[idClient];

            escritor.WriteLine("ID: " + c.Id);
            escritor.WriteLine("Nome: " + c.First);



            float margemEsquerda = e.MarginBounds.Left;
            float margemTopo = e.MarginBounds.Top;
            float posicaoY = 0;

            Font fonteImpressao = new Font("Arial", 12);

            posicaoY = margemTopo + fonteImpressao.GetHeight(e.Graphics);

            e.HasMorePages = false;

            e.Graphics.DrawString(
                data.ToString(),
                fonteImpressao,
                Brushes.Black,
                margemEsquerda,
                posicaoY,
                new StringFormat()
                );

            escritor.Close();
        }

        

        private void dgvDadosClient_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                Guid idClient = Guid.Parse(dgvDadosClient.SelectedRows[0].Cells[0].Value.ToString());

                CtrlClient controle = new CtrlClient();

                Client c = (Client)controle.ExecutarOpBD('o', idClient);

                AddClientControl form = new AddClientControl();

                form.Tag = c;
                
                form.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show("ERRO: " + ex.Message);
            }
            
        }

        
        
    }
}
