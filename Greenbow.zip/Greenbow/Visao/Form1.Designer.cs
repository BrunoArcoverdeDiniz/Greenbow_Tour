﻿namespace Visao
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.bunifuElipse1 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.bunifuDragControl1 = new Bunifu.Framework.UI.BunifuDragControl(this.components);
            this.header = new System.Windows.Forms.Panel();
            this.bunifuCustomLabel1 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuImageButton2 = new Bunifu.Framework.UI.BunifuImageButton();
            this.slidemenu = new System.Windows.Forms.Panel();
            this.panelMain = new System.Windows.Forms.Panel();
            this.bunifuFlatButton4 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.bunifuFlatButton3 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.addClientButton = new Bunifu.Framework.UI.BunifuFlatButton();
            this.addTripButton = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btnMenu = new Bunifu.Framework.UI.BunifuImageButton();
            this.panel1 = new System.Windows.Forms.Panel();
            this.header.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton2)).BeginInit();
            this.slidemenu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnMenu)).BeginInit();
            this.SuspendLayout();
            // 
            // bunifuElipse1
            // 
            this.bunifuElipse1.ElipseRadius = 5;
            this.bunifuElipse1.TargetControl = this;
            // 
            // bunifuDragControl1
            // 
            this.bunifuDragControl1.Fixed = true;
            this.bunifuDragControl1.Horizontal = true;
            this.bunifuDragControl1.TargetControl = null;
            this.bunifuDragControl1.Vertical = true;
            // 
            // header
            // 
            this.header.BackColor = System.Drawing.Color.SeaGreen;
            this.header.Controls.Add(this.bunifuCustomLabel1);
            this.header.Controls.Add(this.bunifuImageButton2);
            this.header.Dock = System.Windows.Forms.DockStyle.Top;
            this.header.Location = new System.Drawing.Point(0, 0);
            this.header.Name = "header";
            this.header.Size = new System.Drawing.Size(1243, 57);
            this.header.TabIndex = 2;
            // 
            // bunifuCustomLabel1
            // 
            this.bunifuCustomLabel1.AutoSize = true;
            this.bunifuCustomLabel1.Font = new System.Drawing.Font("New Berolina MT", 24F);
            this.bunifuCustomLabel1.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.bunifuCustomLabel1.Location = new System.Drawing.Point(3, -1);
            this.bunifuCustomLabel1.Name = "bunifuCustomLabel1";
            this.bunifuCustomLabel1.Size = new System.Drawing.Size(288, 53);
            this.bunifuCustomLabel1.TabIndex = 14;
            this.bunifuCustomLabel1.Text = "Greenbow Tour";
            // 
            // bunifuImageButton2
            // 
            this.bunifuImageButton2.BackColor = System.Drawing.Color.SeaGreen;
            this.bunifuImageButton2.Image = ((System.Drawing.Image)(resources.GetObject("bunifuImageButton2.Image")));
            this.bunifuImageButton2.ImageActive = null;
            this.bunifuImageButton2.Location = new System.Drawing.Point(1197, 12);
            this.bunifuImageButton2.Name = "bunifuImageButton2";
            this.bunifuImageButton2.Size = new System.Drawing.Size(34, 35);
            this.bunifuImageButton2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.bunifuImageButton2.TabIndex = 4;
            this.bunifuImageButton2.TabStop = false;
            this.bunifuImageButton2.Zoom = 10;
            this.bunifuImageButton2.Click += new System.EventHandler(this.bunifuImageButton2_Click_1);
            // 
            // slidemenu
            // 
            this.slidemenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(49)))), ((int)(((byte)(60)))));
            this.slidemenu.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.slidemenu.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.slidemenu.Controls.Add(this.panelMain);
            this.slidemenu.Controls.Add(this.bunifuFlatButton4);
            this.slidemenu.Controls.Add(this.bunifuFlatButton3);
            this.slidemenu.Controls.Add(this.addClientButton);
            this.slidemenu.Controls.Add(this.addTripButton);
            this.slidemenu.Controls.Add(this.btnMenu);
            this.slidemenu.Location = new System.Drawing.Point(0, 57);
            this.slidemenu.Name = "slidemenu";
            this.slidemenu.Size = new System.Drawing.Size(320, 650);
            this.slidemenu.TabIndex = 3;
            // 
            // panelMain
            // 
            this.panelMain.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(49)))), ((int)(((byte)(60)))));
            this.panelMain.Location = new System.Drawing.Point(313, 3);
            this.panelMain.Name = "panelMain";
            this.panelMain.Size = new System.Drawing.Size(930, 650);
            this.panelMain.TabIndex = 2;
            // 
            // bunifuFlatButton4
            // 
            this.bunifuFlatButton4.Activecolor = System.Drawing.Color.DarkGray;
            this.bunifuFlatButton4.BackColor = System.Drawing.Color.SeaGreen;
            this.bunifuFlatButton4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton4.BorderRadius = 3;
            this.bunifuFlatButton4.ButtonText = "       Search Client ";
            this.bunifuFlatButton4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuFlatButton4.DisabledColor = System.Drawing.Color.Gainsboro;
            this.bunifuFlatButton4.ForeColor = System.Drawing.Color.White;
            this.bunifuFlatButton4.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton4.Iconimage = ((System.Drawing.Image)(resources.GetObject("bunifuFlatButton4.Iconimage")));
            this.bunifuFlatButton4.Iconimage_right = null;
            this.bunifuFlatButton4.Iconimage_right_Selected = null;
            this.bunifuFlatButton4.Iconimage_Selected = null;
            this.bunifuFlatButton4.IconMarginLeft = 0;
            this.bunifuFlatButton4.IconMarginRight = 0;
            this.bunifuFlatButton4.IconRightVisible = true;
            this.bunifuFlatButton4.IconRightZoom = 0D;
            this.bunifuFlatButton4.IconVisible = true;
            this.bunifuFlatButton4.IconZoom = 35D;
            this.bunifuFlatButton4.IsTab = true;
            this.bunifuFlatButton4.Location = new System.Drawing.Point(0, 322);
            this.bunifuFlatButton4.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.bunifuFlatButton4.Name = "bunifuFlatButton4";
            this.bunifuFlatButton4.Normalcolor = System.Drawing.Color.SeaGreen;
            this.bunifuFlatButton4.OnHovercolor = System.Drawing.Color.Gainsboro;
            this.bunifuFlatButton4.OnHoverTextColor = System.Drawing.Color.Black;
            this.bunifuFlatButton4.selected = false;
            this.bunifuFlatButton4.Size = new System.Drawing.Size(316, 54);
            this.bunifuFlatButton4.TabIndex = 8;
            this.bunifuFlatButton4.Text = "       Search Client ";
            this.bunifuFlatButton4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bunifuFlatButton4.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton4.TextFont = new System.Drawing.Font("Century Gothic", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuFlatButton4.Click += new System.EventHandler(this.bunifuFlatButton4_Click_1);
            // 
            // bunifuFlatButton3
            // 
            this.bunifuFlatButton3.Activecolor = System.Drawing.Color.DarkGray;
            this.bunifuFlatButton3.BackColor = System.Drawing.Color.SeaGreen;
            this.bunifuFlatButton3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton3.BorderRadius = 3;
            this.bunifuFlatButton3.ButtonText = "       Search Trip ";
            this.bunifuFlatButton3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuFlatButton3.DisabledColor = System.Drawing.Color.Gainsboro;
            this.bunifuFlatButton3.ForeColor = System.Drawing.Color.White;
            this.bunifuFlatButton3.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton3.Iconimage = ((System.Drawing.Image)(resources.GetObject("bunifuFlatButton3.Iconimage")));
            this.bunifuFlatButton3.Iconimage_right = null;
            this.bunifuFlatButton3.Iconimage_right_Selected = null;
            this.bunifuFlatButton3.Iconimage_Selected = null;
            this.bunifuFlatButton3.IconMarginLeft = 0;
            this.bunifuFlatButton3.IconMarginRight = 0;
            this.bunifuFlatButton3.IconRightVisible = true;
            this.bunifuFlatButton3.IconRightZoom = 0D;
            this.bunifuFlatButton3.IconVisible = true;
            this.bunifuFlatButton3.IconZoom = 35D;
            this.bunifuFlatButton3.IsTab = true;
            this.bunifuFlatButton3.Location = new System.Drawing.Point(0, 179);
            this.bunifuFlatButton3.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.bunifuFlatButton3.Name = "bunifuFlatButton3";
            this.bunifuFlatButton3.Normalcolor = System.Drawing.Color.SeaGreen;
            this.bunifuFlatButton3.OnHovercolor = System.Drawing.Color.Gainsboro;
            this.bunifuFlatButton3.OnHoverTextColor = System.Drawing.Color.Black;
            this.bunifuFlatButton3.selected = false;
            this.bunifuFlatButton3.Size = new System.Drawing.Size(316, 54);
            this.bunifuFlatButton3.TabIndex = 5;
            this.bunifuFlatButton3.Text = "       Search Trip ";
            this.bunifuFlatButton3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bunifuFlatButton3.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton3.TextFont = new System.Drawing.Font("Century Gothic", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuFlatButton3.Click += new System.EventHandler(this.bunifuFlatButton3_Click_1);
            // 
            // addClientButton
            // 
            this.addClientButton.Activecolor = System.Drawing.Color.DarkGray;
            this.addClientButton.BackColor = System.Drawing.Color.SeaGreen;
            this.addClientButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.addClientButton.BorderRadius = 3;
            this.addClientButton.ButtonText = "       Add Client";
            this.addClientButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.addClientButton.DisabledColor = System.Drawing.Color.Gainsboro;
            this.addClientButton.ForeColor = System.Drawing.Color.White;
            this.addClientButton.Iconcolor = System.Drawing.Color.Transparent;
            this.addClientButton.Iconimage = ((System.Drawing.Image)(resources.GetObject("addClientButton.Iconimage")));
            this.addClientButton.Iconimage_right = null;
            this.addClientButton.Iconimage_right_Selected = null;
            this.addClientButton.Iconimage_Selected = null;
            this.addClientButton.IconMarginLeft = 0;
            this.addClientButton.IconMarginRight = 0;
            this.addClientButton.IconRightVisible = true;
            this.addClientButton.IconRightZoom = 0D;
            this.addClientButton.IconVisible = true;
            this.addClientButton.IconZoom = 35D;
            this.addClientButton.IsTab = true;
            this.addClientButton.Location = new System.Drawing.Point(0, 251);
            this.addClientButton.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.addClientButton.Name = "addClientButton";
            this.addClientButton.Normalcolor = System.Drawing.Color.SeaGreen;
            this.addClientButton.OnHovercolor = System.Drawing.Color.Gainsboro;
            this.addClientButton.OnHoverTextColor = System.Drawing.Color.Black;
            this.addClientButton.selected = false;
            this.addClientButton.Size = new System.Drawing.Size(316, 54);
            this.addClientButton.TabIndex = 4;
            this.addClientButton.Text = "       Add Client";
            this.addClientButton.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.addClientButton.Textcolor = System.Drawing.Color.White;
            this.addClientButton.TextFont = new System.Drawing.Font("Century Gothic", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addClientButton.Click += new System.EventHandler(this.addClientButton_Click);
            // 
            // addTripButton
            // 
            this.addTripButton.Activecolor = System.Drawing.Color.DarkGray;
            this.addTripButton.BackColor = System.Drawing.Color.SeaGreen;
            this.addTripButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.addTripButton.BorderRadius = 3;
            this.addTripButton.ButtonText = "       Add Trip";
            this.addTripButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.addTripButton.DisabledColor = System.Drawing.Color.SeaGreen;
            this.addTripButton.ForeColor = System.Drawing.Color.White;
            this.addTripButton.Iconcolor = System.Drawing.Color.Transparent;
            this.addTripButton.Iconimage = ((System.Drawing.Image)(resources.GetObject("addTripButton.Iconimage")));
            this.addTripButton.Iconimage_right = null;
            this.addTripButton.Iconimage_right_Selected = null;
            this.addTripButton.Iconimage_Selected = null;
            this.addTripButton.IconMarginLeft = 0;
            this.addTripButton.IconMarginRight = 0;
            this.addTripButton.IconRightVisible = true;
            this.addTripButton.IconRightZoom = 0D;
            this.addTripButton.IconVisible = true;
            this.addTripButton.IconZoom = 35D;
            this.addTripButton.IsTab = true;
            this.addTripButton.Location = new System.Drawing.Point(0, 109);
            this.addTripButton.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.addTripButton.Name = "addTripButton";
            this.addTripButton.Normalcolor = System.Drawing.Color.SeaGreen;
            this.addTripButton.OnHovercolor = System.Drawing.Color.Gainsboro;
            this.addTripButton.OnHoverTextColor = System.Drawing.Color.Black;
            this.addTripButton.selected = false;
            this.addTripButton.Size = new System.Drawing.Size(316, 54);
            this.addTripButton.TabIndex = 2;
            this.addTripButton.Text = "       Add Trip";
            this.addTripButton.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.addTripButton.Textcolor = System.Drawing.Color.White;
            this.addTripButton.TextFont = new System.Drawing.Font("Century Gothic", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addTripButton.Click += new System.EventHandler(this.addTripButton_Click);
            // 
            // btnMenu
            // 
            this.btnMenu.BackColor = System.Drawing.Color.Transparent;
            this.btnMenu.Image = ((System.Drawing.Image)(resources.GetObject("btnMenu.Image")));
            this.btnMenu.ImageActive = null;
            this.btnMenu.Location = new System.Drawing.Point(282, 11);
            this.btnMenu.Name = "btnMenu";
            this.btnMenu.Size = new System.Drawing.Size(25, 33);
            this.btnMenu.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.btnMenu.TabIndex = 2;
            this.btnMenu.TabStop = false;
            this.btnMenu.Zoom = 10;
            this.btnMenu.Click += new System.EventHandler(this.btnMenu_Click_1);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.Control;
            this.panel1.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel1.Location = new System.Drawing.Point(313, 57);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(930, 650);
            this.panel1.TabIndex = 4;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1243, 707);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.slidemenu);
            this.Controls.Add(this.header);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.Text = "Form1";
            this.header.ResumeLayout(false);
            this.header.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton2)).EndInit();
            this.slidemenu.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.btnMenu)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Bunifu.Framework.UI.BunifuElipse bunifuElipse1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel slidemenu;
        private System.Windows.Forms.Panel panelMain;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton4;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton3;
        private Bunifu.Framework.UI.BunifuFlatButton addClientButton;
        private Bunifu.Framework.UI.BunifuFlatButton addTripButton;
        private Bunifu.Framework.UI.BunifuImageButton btnMenu;
        private System.Windows.Forms.Panel header;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel1;
        private Bunifu.Framework.UI.BunifuImageButton bunifuImageButton2;
        private Bunifu.Framework.UI.BunifuDragControl bunifuDragControl1;
    }
}