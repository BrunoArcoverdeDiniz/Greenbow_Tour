﻿namespace Visao
{
    partial class AddTripControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlAddClient = new System.Windows.Forms.Panel();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.txbRoom = new System.Windows.Forms.TextBox();
            this.txbHotel = new System.Windows.Forms.TextBox();
            this.bunifuCustomLabel15 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel16 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.txbLastName = new System.Windows.Forms.TextBox();
            this.mtbTel = new System.Windows.Forms.MaskedTextBox();
            this.txbFirstName = new System.Windows.Forms.TextBox();
            this.bunifuCustomLabel9 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel6 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel11 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.btnSave = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btnCancel = new Bunifu.Framework.UI.BunifuFlatButton();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.calendar = new Bunifu.Framework.UI.BunifuDatepicker();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.txbClr = new System.Windows.Forms.TextBox();
            this.bunifuCustomLabel12 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.rdbRoundTrip = new System.Windows.Forms.RadioButton();
            this.rdbOneWay = new System.Windows.Forms.RadioButton();
            this.bunifuCustomLabel4 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel5 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.txbTo = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.bunifuCustomLabel8 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel10 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.cmbAdults = new System.Windows.Forms.ComboBox();
            this.cmbChildren = new System.Windows.Forms.ComboBox();
            this.bunifuCustomLabel13 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel14 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.txbDriver = new System.Windows.Forms.TextBox();
            this.bunifuCustomLabel1 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel7 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.txbFare = new System.Windows.Forms.TextBox();
            this.bunifuCustomLabel2 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuDatepicker1 = new Bunifu.Framework.UI.BunifuDatepicker();
            this.pnlAddClient.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlAddClient
            // 
            this.pnlAddClient.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(49)))), ((int)(((byte)(60)))));
            this.pnlAddClient.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlAddClient.Controls.Add(this.groupBox4);
            this.pnlAddClient.Controls.Add(this.btnSave);
            this.pnlAddClient.Controls.Add(this.btnCancel);
            this.pnlAddClient.Controls.Add(this.groupBox3);
            this.pnlAddClient.Controls.Add(this.bunifuCustomLabel2);
            this.pnlAddClient.Controls.Add(this.bunifuDatepicker1);
            this.pnlAddClient.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlAddClient.ForeColor = System.Drawing.Color.AntiqueWhite;
            this.pnlAddClient.Location = new System.Drawing.Point(0, 0);
            this.pnlAddClient.Name = "pnlAddClient";
            this.pnlAddClient.Size = new System.Drawing.Size(928, 650);
            this.pnlAddClient.TabIndex = 5;
            // 
            // groupBox4
            // 
            this.groupBox4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(49)))), ((int)(((byte)(60)))));
            this.groupBox4.Controls.Add(this.txbRoom);
            this.groupBox4.Controls.Add(this.txbHotel);
            this.groupBox4.Controls.Add(this.bunifuCustomLabel15);
            this.groupBox4.Controls.Add(this.bunifuCustomLabel16);
            this.groupBox4.Controls.Add(this.txbLastName);
            this.groupBox4.Controls.Add(this.mtbTel);
            this.groupBox4.Controls.Add(this.txbFirstName);
            this.groupBox4.Controls.Add(this.bunifuCustomLabel9);
            this.groupBox4.Controls.Add(this.bunifuCustomLabel6);
            this.groupBox4.Controls.Add(this.bunifuCustomLabel11);
            this.groupBox4.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox4.ForeColor = System.Drawing.Color.Gainsboro;
            this.groupBox4.Location = new System.Drawing.Point(589, 63);
            this.groupBox4.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox4.Size = new System.Drawing.Size(314, 504);
            this.groupBox4.TabIndex = 60;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Passenger Details";
            // 
            // txbRoom
            // 
            this.txbRoom.BackColor = System.Drawing.Color.Gainsboro;
            this.txbRoom.Font = new System.Drawing.Font("Century Gothic", 10F);
            this.txbRoom.Location = new System.Drawing.Point(86, 302);
            this.txbRoom.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txbRoom.Name = "txbRoom";
            this.txbRoom.Size = new System.Drawing.Size(153, 32);
            this.txbRoom.TabIndex = 72;
            // 
            // txbHotel
            // 
            this.txbHotel.BackColor = System.Drawing.Color.Gainsboro;
            this.txbHotel.Font = new System.Drawing.Font("Century Gothic", 10F);
            this.txbHotel.Location = new System.Drawing.Point(86, 240);
            this.txbHotel.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txbHotel.Name = "txbHotel";
            this.txbHotel.Size = new System.Drawing.Size(153, 32);
            this.txbHotel.TabIndex = 70;
            // 
            // bunifuCustomLabel15
            // 
            this.bunifuCustomLabel15.AutoSize = true;
            this.bunifuCustomLabel15.ForeColor = System.Drawing.Color.Gainsboro;
            this.bunifuCustomLabel15.Location = new System.Drawing.Point(12, 302);
            this.bunifuCustomLabel15.Name = "bunifuCustomLabel15";
            this.bunifuCustomLabel15.Size = new System.Drawing.Size(73, 23);
            this.bunifuCustomLabel15.TabIndex = 71;
            this.bunifuCustomLabel15.Text = "Room ";
            // 
            // bunifuCustomLabel16
            // 
            this.bunifuCustomLabel16.AutoSize = true;
            this.bunifuCustomLabel16.ForeColor = System.Drawing.Color.Gainsboro;
            this.bunifuCustomLabel16.Location = new System.Drawing.Point(13, 243);
            this.bunifuCustomLabel16.Name = "bunifuCustomLabel16";
            this.bunifuCustomLabel16.Size = new System.Drawing.Size(62, 23);
            this.bunifuCustomLabel16.TabIndex = 69;
            this.bunifuCustomLabel16.Text = "Hotel";
            // 
            // txbLastName
            // 
            this.txbLastName.BackColor = System.Drawing.Color.Gainsboro;
            this.txbLastName.Font = new System.Drawing.Font("Century Gothic", 10F);
            this.txbLastName.Location = new System.Drawing.Point(86, 117);
            this.txbLastName.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txbLastName.Name = "txbLastName";
            this.txbLastName.Size = new System.Drawing.Size(206, 32);
            this.txbLastName.TabIndex = 68;
            // 
            // mtbTel
            // 
            this.mtbTel.BackColor = System.Drawing.Color.Gainsboro;
            this.mtbTel.Font = new System.Drawing.Font("Century Gothic", 10F);
            this.mtbTel.Location = new System.Drawing.Point(86, 178);
            this.mtbTel.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.mtbTel.Mask = "(99) 90000-0000";
            this.mtbTel.Name = "mtbTel";
            this.mtbTel.Size = new System.Drawing.Size(153, 32);
            this.mtbTel.TabIndex = 34;
            // 
            // txbFirstName
            // 
            this.txbFirstName.BackColor = System.Drawing.Color.Gainsboro;
            this.txbFirstName.Font = new System.Drawing.Font("Century Gothic", 10F);
            this.txbFirstName.Location = new System.Drawing.Point(86, 56);
            this.txbFirstName.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txbFirstName.Name = "txbFirstName";
            this.txbFirstName.Size = new System.Drawing.Size(206, 32);
            this.txbFirstName.TabIndex = 66;
            // 
            // bunifuCustomLabel9
            // 
            this.bunifuCustomLabel9.AutoSize = true;
            this.bunifuCustomLabel9.ForeColor = System.Drawing.Color.Gainsboro;
            this.bunifuCustomLabel9.Location = new System.Drawing.Point(12, 120);
            this.bunifuCustomLabel9.Name = "bunifuCustomLabel9";
            this.bunifuCustomLabel9.Size = new System.Drawing.Size(48, 23);
            this.bunifuCustomLabel9.TabIndex = 67;
            this.bunifuCustomLabel9.Text = "Last";
            // 
            // bunifuCustomLabel6
            // 
            this.bunifuCustomLabel6.AutoSize = true;
            this.bunifuCustomLabel6.ForeColor = System.Drawing.Color.Gainsboro;
            this.bunifuCustomLabel6.Location = new System.Drawing.Point(14, 182);
            this.bunifuCustomLabel6.Name = "bunifuCustomLabel6";
            this.bunifuCustomLabel6.Size = new System.Drawing.Size(36, 23);
            this.bunifuCustomLabel6.TabIndex = 35;
            this.bunifuCustomLabel6.Text = "Tel";
            // 
            // bunifuCustomLabel11
            // 
            this.bunifuCustomLabel11.AutoSize = true;
            this.bunifuCustomLabel11.ForeColor = System.Drawing.Color.Gainsboro;
            this.bunifuCustomLabel11.Location = new System.Drawing.Point(12, 62);
            this.bunifuCustomLabel11.Name = "bunifuCustomLabel11";
            this.bunifuCustomLabel11.Size = new System.Drawing.Size(44, 23);
            this.bunifuCustomLabel11.TabIndex = 65;
            this.bunifuCustomLabel11.Text = "First";
            // 
            // btnSave
            // 
            this.btnSave.Activecolor = System.Drawing.Color.DarkGray;
            this.btnSave.BackColor = System.Drawing.Color.Gainsboro;
            this.btnSave.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnSave.BorderRadius = 0;
            this.btnSave.ButtonText = "Save";
            this.btnSave.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSave.DisabledColor = System.Drawing.Color.Gainsboro;
            this.btnSave.Iconcolor = System.Drawing.Color.Transparent;
            this.btnSave.Iconimage = null;
            this.btnSave.Iconimage_right = null;
            this.btnSave.Iconimage_right_Selected = null;
            this.btnSave.Iconimage_Selected = null;
            this.btnSave.IconMarginLeft = 0;
            this.btnSave.IconMarginRight = 0;
            this.btnSave.IconRightVisible = true;
            this.btnSave.IconRightZoom = 0D;
            this.btnSave.IconVisible = true;
            this.btnSave.IconZoom = 35D;
            this.btnSave.IsTab = true;
            this.btnSave.Location = new System.Drawing.Point(788, 587);
            this.btnSave.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnSave.Name = "btnSave";
            this.btnSave.Normalcolor = System.Drawing.Color.Gainsboro;
            this.btnSave.OnHovercolor = System.Drawing.Color.SeaGreen;
            this.btnSave.OnHoverTextColor = System.Drawing.Color.White;
            this.btnSave.selected = false;
            this.btnSave.Size = new System.Drawing.Size(115, 38);
            this.btnSave.TabIndex = 63;
            this.btnSave.Text = "Save";
            this.btnSave.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnSave.Textcolor = System.Drawing.Color.SeaGreen;
            this.btnSave.TextFont = new System.Drawing.Font("Century Gothic", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click_1);
            // 
            // btnCancel
            // 
            this.btnCancel.Activecolor = System.Drawing.Color.DarkGray;
            this.btnCancel.BackColor = System.Drawing.Color.Gainsboro;
            this.btnCancel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnCancel.BorderRadius = 0;
            this.btnCancel.ButtonText = "Cancel";
            this.btnCancel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCancel.DisabledColor = System.Drawing.Color.Gainsboro;
            this.btnCancel.Iconcolor = System.Drawing.Color.Transparent;
            this.btnCancel.Iconimage = null;
            this.btnCancel.Iconimage_right = null;
            this.btnCancel.Iconimage_right_Selected = null;
            this.btnCancel.Iconimage_Selected = null;
            this.btnCancel.IconMarginLeft = 0;
            this.btnCancel.IconMarginRight = 0;
            this.btnCancel.IconRightVisible = true;
            this.btnCancel.IconRightZoom = 0D;
            this.btnCancel.IconVisible = true;
            this.btnCancel.IconZoom = 35D;
            this.btnCancel.IsTab = true;
            this.btnCancel.Location = new System.Drawing.Point(655, 587);
            this.btnCancel.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Normalcolor = System.Drawing.Color.Gainsboro;
            this.btnCancel.OnHovercolor = System.Drawing.Color.SeaGreen;
            this.btnCancel.OnHoverTextColor = System.Drawing.Color.White;
            this.btnCancel.selected = false;
            this.btnCancel.Size = new System.Drawing.Size(115, 38);
            this.btnCancel.TabIndex = 62;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnCancel.Textcolor = System.Drawing.Color.SeaGreen;
            this.btnCancel.TextFont = new System.Drawing.Font("Century Gothic", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(49)))), ((int)(((byte)(60)))));
            this.groupBox3.Controls.Add(this.calendar);
            this.groupBox3.Controls.Add(this.textBox1);
            this.groupBox3.Controls.Add(this.txbClr);
            this.groupBox3.Controls.Add(this.bunifuCustomLabel12);
            this.groupBox3.Controls.Add(this.groupBox2);
            this.groupBox3.Controls.Add(this.txbTo);
            this.groupBox3.Controls.Add(this.groupBox1);
            this.groupBox3.Controls.Add(this.bunifuCustomLabel13);
            this.groupBox3.Controls.Add(this.bunifuCustomLabel14);
            this.groupBox3.Controls.Add(this.txbDriver);
            this.groupBox3.Controls.Add(this.bunifuCustomLabel1);
            this.groupBox3.Controls.Add(this.bunifuCustomLabel7);
            this.groupBox3.Controls.Add(this.txbFare);
            this.groupBox3.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.ForeColor = System.Drawing.Color.Gainsboro;
            this.groupBox3.Location = new System.Drawing.Point(22, 63);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox3.Size = new System.Drawing.Size(557, 504);
            this.groupBox3.TabIndex = 51;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Trip Details";
            // 
            // calendar
            // 
            this.calendar.BackColor = System.Drawing.Color.Gainsboro;
            this.calendar.BorderRadius = 0;
            this.calendar.Font = new System.Drawing.Font("Century Gothic", 6F);
            this.calendar.ForeColor = System.Drawing.Color.Black;
            this.calendar.Format = System.Windows.Forms.DateTimePickerFormat.Long;
            this.calendar.FormatCustom = null;
            this.calendar.Location = new System.Drawing.Point(143, 53);
            this.calendar.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.calendar.Name = "calendar";
            this.calendar.Size = new System.Drawing.Size(397, 32);
            this.calendar.TabIndex = 66;
            this.calendar.Value = new System.DateTime(2018, 5, 3, 9, 31, 18, 678);
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.Color.Gainsboro;
            this.textBox1.Font = new System.Drawing.Font("Century Gothic", 10F);
            this.textBox1.Location = new System.Drawing.Point(80, 121);
            this.textBox1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(460, 32);
            this.textBox1.TabIndex = 65;
            // 
            // txbClr
            // 
            this.txbClr.BackColor = System.Drawing.Color.Gainsboro;
            this.txbClr.Font = new System.Drawing.Font("Century Gothic", 10F);
            this.txbClr.Location = new System.Drawing.Point(365, 302);
            this.txbClr.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txbClr.Name = "txbClr";
            this.txbClr.Size = new System.Drawing.Size(175, 32);
            this.txbClr.TabIndex = 59;
            // 
            // bunifuCustomLabel12
            // 
            this.bunifuCustomLabel12.AutoSize = true;
            this.bunifuCustomLabel12.ForeColor = System.Drawing.Color.Gainsboro;
            this.bunifuCustomLabel12.Location = new System.Drawing.Point(302, 308);
            this.bunifuCustomLabel12.Name = "bunifuCustomLabel12";
            this.bunifuCustomLabel12.Size = new System.Drawing.Size(37, 23);
            this.bunifuCustomLabel12.TabIndex = 58;
            this.bunifuCustomLabel12.Text = "Clr";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.rdbRoundTrip);
            this.groupBox2.Controls.Add(this.rdbOneWay);
            this.groupBox2.Controls.Add(this.bunifuCustomLabel4);
            this.groupBox2.Controls.Add(this.bunifuCustomLabel5);
            this.groupBox2.ForeColor = System.Drawing.Color.Gainsboro;
            this.groupBox2.Location = new System.Drawing.Point(299, 360);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox2.Size = new System.Drawing.Size(241, 125);
            this.groupBox2.TabIndex = 50;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Trip";
            // 
            // rdbRoundTrip
            // 
            this.rdbRoundTrip.AutoSize = true;
            this.rdbRoundTrip.Location = new System.Drawing.Point(24, 74);
            this.rdbRoundTrip.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.rdbRoundTrip.Name = "rdbRoundTrip";
            this.rdbRoundTrip.Size = new System.Drawing.Size(135, 27);
            this.rdbRoundTrip.TabIndex = 47;
            this.rdbRoundTrip.TabStop = true;
            this.rdbRoundTrip.Text = "Round Trip";
            this.rdbRoundTrip.UseVisualStyleBackColor = true;
            // 
            // rdbOneWay
            // 
            this.rdbOneWay.AutoSize = true;
            this.rdbOneWay.Location = new System.Drawing.Point(24, 40);
            this.rdbOneWay.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.rdbOneWay.Name = "rdbOneWay";
            this.rdbOneWay.Size = new System.Drawing.Size(125, 27);
            this.rdbOneWay.TabIndex = 46;
            this.rdbOneWay.TabStop = true;
            this.rdbOneWay.Text = "One Way";
            this.rdbOneWay.UseVisualStyleBackColor = true;
            // 
            // bunifuCustomLabel4
            // 
            this.bunifuCustomLabel4.AutoSize = true;
            this.bunifuCustomLabel4.Location = new System.Drawing.Point(-166, 9);
            this.bunifuCustomLabel4.Name = "bunifuCustomLabel4";
            this.bunifuCustomLabel4.Size = new System.Drawing.Size(111, 23);
            this.bunifuCustomLabel4.TabIndex = 30;
            this.bunifuCustomLabel4.Text = "First Name";
            // 
            // bunifuCustomLabel5
            // 
            this.bunifuCustomLabel5.AutoSize = true;
            this.bunifuCustomLabel5.Location = new System.Drawing.Point(-166, 49);
            this.bunifuCustomLabel5.Name = "bunifuCustomLabel5";
            this.bunifuCustomLabel5.Size = new System.Drawing.Size(115, 23);
            this.bunifuCustomLabel5.TabIndex = 32;
            this.bunifuCustomLabel5.Text = "Last Name";
            // 
            // txbTo
            // 
            this.txbTo.BackColor = System.Drawing.Color.Gainsboro;
            this.txbTo.Font = new System.Drawing.Font("Century Gothic", 10F);
            this.txbTo.Location = new System.Drawing.Point(80, 182);
            this.txbTo.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txbTo.Name = "txbTo";
            this.txbTo.Size = new System.Drawing.Size(460, 32);
            this.txbTo.TabIndex = 56;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.bunifuCustomLabel8);
            this.groupBox1.Controls.Add(this.bunifuCustomLabel10);
            this.groupBox1.Controls.Add(this.cmbAdults);
            this.groupBox1.Controls.Add(this.cmbChildren);
            this.groupBox1.ForeColor = System.Drawing.Color.Gainsboro;
            this.groupBox1.Location = new System.Drawing.Point(12, 360);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox1.Size = new System.Drawing.Size(241, 125);
            this.groupBox1.TabIndex = 48;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Passengers";
            // 
            // bunifuCustomLabel8
            // 
            this.bunifuCustomLabel8.AutoSize = true;
            this.bunifuCustomLabel8.Location = new System.Drawing.Point(109, 79);
            this.bunifuCustomLabel8.Name = "bunifuCustomLabel8";
            this.bunifuCustomLabel8.Size = new System.Drawing.Size(91, 23);
            this.bunifuCustomLabel8.TabIndex = 48;
            this.bunifuCustomLabel8.Text = "Children";
            // 
            // bunifuCustomLabel10
            // 
            this.bunifuCustomLabel10.AutoSize = true;
            this.bunifuCustomLabel10.Location = new System.Drawing.Point(109, 44);
            this.bunifuCustomLabel10.Name = "bunifuCustomLabel10";
            this.bunifuCustomLabel10.Size = new System.Drawing.Size(71, 23);
            this.bunifuCustomLabel10.TabIndex = 49;
            this.bunifuCustomLabel10.Text = "Adults";
            // 
            // cmbAdults
            // 
            this.cmbAdults.BackColor = System.Drawing.Color.Gainsboro;
            this.cmbAdults.Font = new System.Drawing.Font("Century Gothic", 10F);
            this.cmbAdults.FormattingEnabled = true;
            this.cmbAdults.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.cmbAdults.Location = new System.Drawing.Point(14, 41);
            this.cmbAdults.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.cmbAdults.Name = "cmbAdults";
            this.cmbAdults.Size = new System.Drawing.Size(48, 31);
            this.cmbAdults.TabIndex = 46;
            // 
            // cmbChildren
            // 
            this.cmbChildren.BackColor = System.Drawing.Color.Gainsboro;
            this.cmbChildren.Font = new System.Drawing.Font("Century Gothic", 10F);
            this.cmbChildren.FormattingEnabled = true;
            this.cmbChildren.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.cmbChildren.Location = new System.Drawing.Point(14, 76);
            this.cmbChildren.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.cmbChildren.Name = "cmbChildren";
            this.cmbChildren.Size = new System.Drawing.Size(48, 31);
            this.cmbChildren.TabIndex = 47;
            // 
            // bunifuCustomLabel13
            // 
            this.bunifuCustomLabel13.AutoSize = true;
            this.bunifuCustomLabel13.ForeColor = System.Drawing.Color.Gainsboro;
            this.bunifuCustomLabel13.Location = new System.Drawing.Point(7, 186);
            this.bunifuCustomLabel13.Name = "bunifuCustomLabel13";
            this.bunifuCustomLabel13.Size = new System.Drawing.Size(31, 23);
            this.bunifuCustomLabel13.TabIndex = 55;
            this.bunifuCustomLabel13.Text = "To";
            // 
            // bunifuCustomLabel14
            // 
            this.bunifuCustomLabel14.AutoSize = true;
            this.bunifuCustomLabel14.ForeColor = System.Drawing.Color.Gainsboro;
            this.bunifuCustomLabel14.Location = new System.Drawing.Point(8, 124);
            this.bunifuCustomLabel14.Name = "bunifuCustomLabel14";
            this.bunifuCustomLabel14.Size = new System.Drawing.Size(58, 23);
            this.bunifuCustomLabel14.TabIndex = 53;
            this.bunifuCustomLabel14.Text = "From";
            // 
            // txbDriver
            // 
            this.txbDriver.BackColor = System.Drawing.Color.Gainsboro;
            this.txbDriver.Font = new System.Drawing.Font("Century Gothic", 10F);
            this.txbDriver.Location = new System.Drawing.Point(80, 240);
            this.txbDriver.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txbDriver.Name = "txbDriver";
            this.txbDriver.Size = new System.Drawing.Size(203, 32);
            this.txbDriver.TabIndex = 26;
            // 
            // bunifuCustomLabel1
            // 
            this.bunifuCustomLabel1.AutoSize = true;
            this.bunifuCustomLabel1.ForeColor = System.Drawing.Color.Gainsboro;
            this.bunifuCustomLabel1.Location = new System.Drawing.Point(8, 237);
            this.bunifuCustomLabel1.Name = "bunifuCustomLabel1";
            this.bunifuCustomLabel1.Size = new System.Drawing.Size(66, 23);
            this.bunifuCustomLabel1.TabIndex = 9;
            this.bunifuCustomLabel1.Text = "Driver";
            // 
            // bunifuCustomLabel7
            // 
            this.bunifuCustomLabel7.AutoSize = true;
            this.bunifuCustomLabel7.ForeColor = System.Drawing.Color.Gainsboro;
            this.bunifuCustomLabel7.Location = new System.Drawing.Point(302, 246);
            this.bunifuCustomLabel7.Name = "bunifuCustomLabel7";
            this.bunifuCustomLabel7.Size = new System.Drawing.Size(53, 23);
            this.bunifuCustomLabel7.TabIndex = 41;
            this.bunifuCustomLabel7.Text = "Fare";
            // 
            // txbFare
            // 
            this.txbFare.BackColor = System.Drawing.Color.Gainsboro;
            this.txbFare.Font = new System.Drawing.Font("Century Gothic", 10F);
            this.txbFare.Location = new System.Drawing.Point(365, 240);
            this.txbFare.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txbFare.Name = "txbFare";
            this.txbFare.Size = new System.Drawing.Size(175, 32);
            this.txbFare.TabIndex = 42;
            // 
            // bunifuCustomLabel2
            // 
            this.bunifuCustomLabel2.AutoSize = true;
            this.bunifuCustomLabel2.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel2.ForeColor = System.Drawing.Color.Gainsboro;
            this.bunifuCustomLabel2.Location = new System.Drawing.Point(382, 11);
            this.bunifuCustomLabel2.Name = "bunifuCustomLabel2";
            this.bunifuCustomLabel2.Size = new System.Drawing.Size(132, 30);
            this.bunifuCustomLabel2.TabIndex = 27;
            this.bunifuCustomLabel2.Text = "Add a Trip";
            // 
            // bunifuDatepicker1
            // 
            this.bunifuDatepicker1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.bunifuDatepicker1.BorderRadius = 5;
            this.bunifuDatepicker1.ForeColor = System.Drawing.Color.Black;
            this.bunifuDatepicker1.Format = System.Windows.Forms.DateTimePickerFormat.Long;
            this.bunifuDatepicker1.FormatCustom = null;
            this.bunifuDatepicker1.Location = new System.Drawing.Point(22, 41);
            this.bunifuDatepicker1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.bunifuDatepicker1.Name = "bunifuDatepicker1";
            this.bunifuDatepicker1.Size = new System.Drawing.Size(0, 0);
            this.bunifuDatepicker1.TabIndex = 24;
            this.bunifuDatepicker1.Value = new System.DateTime(2018, 4, 12, 12, 5, 41, 736);
            // 
            // AddTripControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.pnlAddClient);
            this.Name = "AddTripControl";
            this.Size = new System.Drawing.Size(928, 650);
            this.pnlAddClient.ResumeLayout(false);
            this.pnlAddClient.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlAddClient;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox txbRoom;
        private System.Windows.Forms.TextBox txbHotel;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel15;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel16;
        private System.Windows.Forms.TextBox txbLastName;
        private System.Windows.Forms.MaskedTextBox mtbTel;
        private System.Windows.Forms.TextBox txbFirstName;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel9;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel6;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel11;
        private Bunifu.Framework.UI.BunifuFlatButton btnSave;
        private Bunifu.Framework.UI.BunifuFlatButton btnCancel;
        private System.Windows.Forms.GroupBox groupBox3;
        private Bunifu.Framework.UI.BunifuDatepicker calendar;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox txbClr;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel12;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RadioButton rdbRoundTrip;
        private System.Windows.Forms.RadioButton rdbOneWay;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel4;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel5;
        private System.Windows.Forms.TextBox txbTo;
        private System.Windows.Forms.GroupBox groupBox1;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel8;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel10;
        private System.Windows.Forms.ComboBox cmbAdults;
        private System.Windows.Forms.ComboBox cmbChildren;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel13;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel14;
        private System.Windows.Forms.TextBox txbDriver;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel1;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel7;
        private System.Windows.Forms.TextBox txbFare;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel2;
        private Bunifu.Framework.UI.BunifuDatepicker bunifuDatepicker1;
    }
}
